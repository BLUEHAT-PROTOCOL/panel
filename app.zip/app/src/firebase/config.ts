// ============================================
// BLUEHAT STORE - FIREBASE CONFIGURATION
// ============================================

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, FacebookAuthProvider } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getMessaging, isSupported } from 'firebase/messaging';
import { getAnalytics, isSupported as isAnalyticsSupported } from 'firebase/analytics';

// Firebase configuration from user
const firebaseConfig = {
  apiKey: "AIzaSyDrGYHojF8ieYbcg-wQSyU9xW69Iff8Klk",
  authDomain: "fahdil-market-3525c.firebaseapp.com",
  projectId: "fahdil-market-3525c",
  storageBucket: "fahdil-market-3525c.appspot.com",
  messagingSenderId: "690261822236",
  appId: "1:690261822236:web:ea3f35ba41da4e7ad648d9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Initialize Analytics (conditionally)
export const initializeAnalytics = async () => {
  if (await isAnalyticsSupported()) {
    return getAnalytics(app);
  }
  return null;
};

// Initialize Messaging (conditionally)
export const initializeMessaging = async () => {
  if (await isSupported()) {
    return getMessaging(app);
  }
  return null;
};

// Auth providers
export const googleProvider = new GoogleAuthProvider();
export const facebookProvider = new FacebookAuthProvider();

// Configure auth providers
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

facebookProvider.setCustomParameters({
  display: 'popup'
});

// Collection names
export const COLLECTIONS = {
  USERS: 'users',
  PRODUCTS: 'products',
  CATEGORIES: 'categories',
  ORDERS: 'orders',
  ORDER_ITEMS: 'order_items',
  PAYMENTS: 'payments',
  PAYMENT_PROOFS: 'payment_proofs',
  CART_ITEMS: 'cart_items',
  WISHLIST_ITEMS: 'wishlist_items',
  REVIEWS: 'reviews',
  ADDRESSES: 'addresses',
  COUPONS: 'coupons',
  NOTIFICATIONS: 'notifications',
  CHATS: 'chats',
  CHAT_MESSAGES: 'chat_messages',
  ACTIVITY_LOGS: 'activity_logs',
  WEBHOOKS: 'webhooks',
  SETTINGS: 'settings',
  ANALYTICS_EVENTS: 'analytics_events',
  PREMIUM_ACCOUNTS: 'premium_accounts',
  REDEEM_CODES: 'redeem_codes',
  LICENSE_KEYS: 'license_keys',
  DIGITAL_FILES: 'digital_files'
} as const;

// Storage paths
export const STORAGE_PATHS = {
  PRODUCTS: 'products',
  PAYMENT_PROOFS: 'payment_proofs',
  AVATARS: 'avatars',
  REVIEW_IMAGES: 'review_images',
  DIGITAL_FILES: 'digital_files',
  CATEGORY_IMAGES: 'categories',
  BANNERS: 'banners'
} as const;

export default app;
