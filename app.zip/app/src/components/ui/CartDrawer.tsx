// ============================================
// BLUEHAT STORE - CART DRAWER COMPONENT
// ============================================

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Plus, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { useCart } from '@/contexts';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

export function CartDrawer({ isOpen, onClose, onCheckout }: CartDrawerProps) {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="cart-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            className="cart-drawer"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          >
            {/* Header */}
            <div className="cart-header">
              <div className="cart-title">
                <ShoppingBag size={24} />
                <h3>Shopping Cart</h3>
                <span className="cart-count">({cart.itemCount} items)</span>
              </div>
              <motion.button
                className="cart-close"
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={24} />
              </motion.button>
            </div>

            {/* Content */}
            <div className="cart-content">
              {cart.items.length === 0 ? (
                <div className="cart-empty">
                  <motion.div
                    className="empty-icon"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 200 }}
                  >
                    <ShoppingBag size={64} />
                  </motion.div>
                  <h4>Your cart is empty</h4>
                  <p>Add some products to get started!</p>
                </div>
              ) : (
                <>
                  <div className="cart-items">
                    <AnimatePresence mode="popLayout">
                      {cart.items.map((item) => (
                        <motion.div
                          key={item.id}
                          className="cart-item"
                          layout
                          initial={{ opacity: 0, x: 50 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -50 }}
                          transition={{ duration: 0.3 }}
                        >
                          <div className="item-image">
                            <img 
                              src={item.product.thumbnail} 
                              alt={item.product.name}
                              loading="lazy"
                            />
                          </div>
                          
                          <div className="item-details">
                            <h4 className="item-name">{item.product.name}</h4>
                            <p className="item-category">{item.product.category}</p>
                            <p className="item-price">
                              {formatPrice(item.price)}
                            </p>
                          </div>

                          <div className="item-actions">
                            <div className="quantity-control">
                              <motion.button
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                disabled={item.quantity <= 1}
                              >
                                <Minus size={14} />
                              </motion.button>
                              <span>{item.quantity}</span>
                              <motion.button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <Plus size={14} />
                              </motion.button>
                            </div>
                            
                            <motion.button
                              className="remove-btn"
                              onClick={() => removeFromCart(item.id)}
                              whileHover={{ scale: 1.1, color: '#EF4444' }}
                              whileTap={{ scale: 0.9 }}
                            >
                              <Trash2 size={18} />
                            </motion.button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  {cart.items.length > 0 && (
                    <motion.button
                      className="clear-cart-btn"
                      onClick={clearCart}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      whileHover={{ scale: 1.02 }}
                    >
                      <Trash2 size={16} />
                      Clear Cart
                    </motion.button>
                  )}
                </>
              )}
            </div>

            {/* Footer */}
            {cart.items.length > 0 && (
              <div className="cart-footer">
                <div className="cart-summary">
                  <div className="summary-row">
                    <span>Subtotal</span>
                    <span>{formatPrice(cart.subtotal)}</span>
                  </div>
                  {cart.discount > 0 && (
                    <div className="summary-row discount">
                      <span>Discount</span>
                      <span>-{formatPrice(cart.discount)}</span>
                    </div>
                  )}
                  <div className="summary-row">
                    <span>Tax</span>
                    <span>{formatPrice(cart.tax)}</span>
                  </div>
                  <div className="summary-row total">
                    <span>Total</span>
                    <span>{formatPrice(cart.total)}</span>
                  </div>
                </div>

                <motion.button
                  className="checkout-btn"
                  onClick={() => {
                    onClose();
                    onCheckout();
                  }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Proceed to Checkout
                  <ArrowRight size={18} />
                </motion.button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
