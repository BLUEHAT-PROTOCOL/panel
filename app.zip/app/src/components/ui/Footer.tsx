// ============================================
// BLUEHAT STORE - FOOTER COMPONENT
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin,
  Send,
  ExternalLink
} from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string, params?: any) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const quickLinks = [
    { label: 'Home', page: 'home' },
    { label: 'Products', page: 'search' },
    { label: 'Categories', page: 'search' },
    { label: 'Deals', page: 'search' },
    { label: 'About Us', page: 'home' },
  ];

  const supportLinks = [
    { label: 'Help Center', page: 'support' },
    { label: 'FAQs', page: 'support' },
    { label: 'Contact Us', page: 'support' },
    { label: 'Terms of Service', page: 'terms' },
    { label: 'Privacy Policy', page: 'privacy' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter subscription
    alert('Thank you for subscribing!');
  };

  return (
    <footer className="footer">
      {/* Animated Border Top */}
      <div className="footer-border" />
      
      <div className="footer-container">
        {/* Brand Column */}
        <motion.div 
          className="footer-brand"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="footer-logo" onClick={() => onNavigate('home')}>
            <svg viewBox="0 0 40 40" className="logo-svg">
              <defs>
                <linearGradient id="footerLogoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563EB" />
                  <stop offset="100%" stopColor="#38BDF8" />
                </linearGradient>
              </defs>
              <path
                d="M20 2L38 11V29L20 38L2 29V11L20 2Z"
                fill="none"
                stroke="url(#footerLogoGradient)"
                strokeWidth="2"
              />
              <path
                d="M20 10L30 15V25L20 30L10 25V15L20 10Z"
                fill="url(#footerLogoGradient)"
              />
            </svg>
            <span className="logo-text">BLUEHAT</span>
          </div>
          <p className="brand-description">
            Your trusted marketplace for premium digital products. 
            Secure, instant, and built for the future.
          </p>
          <div className="contact-info">
            <div className="contact-item">
              <Mail size={16} />
              <span>support@bluehat.store</span>
            </div>
            <div className="contact-item">
              <Phone size={16} />
              <span>+62 812-3456-7890</span>
            </div>
            <div className="contact-item">
              <MapPin size={16} />
              <span>Jakarta, Indonesia</span>
            </div>
          </div>
        </motion.div>

        {/* Quick Links */}
        <motion.div 
          className="footer-links-column"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          viewport={{ once: true }}
        >
          <h4 className="footer-title">Quick Links</h4>
          <ul className="footer-links">
            {quickLinks.map((link) => (
              <li key={link.label}>
                <button 
                  className="footer-link"
                  onClick={() => onNavigate(link.page)}
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Support Links */}
        <motion.div 
          className="footer-links-column"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <h4 className="footer-title">Support</h4>
          <ul className="footer-links">
            {supportLinks.map((link) => (
              <li key={link.label}>
                <button 
                  className="footer-link"
                  onClick={() => onNavigate(link.page)}
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Newsletter */}
        <motion.div 
          className="footer-newsletter"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <h4 className="footer-title">Newsletter</h4>
          <p className="newsletter-description">
            Subscribe to get updates on new products and exclusive deals.
          </p>
          <form onSubmit={handleSubscribe} className="newsletter-form">
            <input
              type="email"
              placeholder="Enter your email"
              required
            />
            <motion.button
              type="submit"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Send size={18} />
            </motion.button>
          </form>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <div className="footer-bottom">
        <div className="footer-bottom-container">
          <p className="copyright">
            © 2024 Bluehat Store. All rights reserved.
          </p>
          <div className="social-links">
            {socialLinks.map((social) => (
              <motion.a
                key={social.label}
                href={social.href}
                className="social-link"
                whileHover={{ scale: 1.2, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
                aria-label={social.label}
              >
                <social.icon size={20} />
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
