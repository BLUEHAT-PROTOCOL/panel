// ============================================
// BLUEHAT STORE - NOTIFICATION TOAST COMPONENT
// ============================================

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';
import { useNotification } from '@/contexts';

const iconMap = {
  success: CheckCircle,
  error: AlertCircle,
  info: Info,
  warning: AlertTriangle
};

const colorMap = {
  success: '#10B981',
  error: '#EF4444',
  info: '#3B82F6',
  warning: '#F59E0B'
};

export function NotificationToast() {
  const { notifications, markAsRead } = useNotification();

  // Auto-dismiss notifications after 5 seconds
  useEffect(() => {
    const unreadNotifications = notifications.filter(n => !n.isRead);
    
    unreadNotifications.forEach(notification => {
      const timer = setTimeout(() => {
        markAsRead(notification.id);
      }, 5000);

      return () => clearTimeout(timer);
    });
  }, [notifications, markAsRead]);

  const unreadNotifications = notifications.filter(n => !n.isRead).slice(0, 3);

  return (
    <div className="notification-container">
      <AnimatePresence>
        {unreadNotifications.map((notification, index) => {
          const Icon = iconMap[notification.type as keyof typeof iconMap] || Info;
          const color = colorMap[notification.type as keyof typeof colorMap] || '#3B82F6';

          return (
            <motion.div
              key={notification.id}
              className="notification-toast"
              initial={{ opacity: 0, x: 100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100, scale: 0.9 }}
              transition={{ 
                duration: 0.3,
                delay: index * 0.1
              }}
              style={{ 
                borderLeftColor: color,
                top: `${index * 80 + 20}px`
              }}
            >
              <div 
                className="notification-icon"
                style={{ color }}
              >
                <Icon size={20} />
              </div>
              
              <div className="notification-content">
                <h4 className="notification-title">{notification.title}</h4>
                <p className="notification-message">{notification.message}</p>
              </div>

              <motion.button
                className="notification-close"
                onClick={() => markAsRead(notification.id)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={16} />
              </motion.button>

              {/* Progress bar */}
              <motion.div
                className="notification-progress"
                style={{ backgroundColor: color }}
                initial={{ width: '100%' }}
                animate={{ width: '0%' }}
                transition={{ duration: 5, ease: 'linear' }}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
