// ============================================
// BLUEHAT STORE - NAVBAR COMPONENT
// ============================================

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShoppingCart, 
  User, 
  Search, 
  Menu, 
  X, 
  Heart, 
  Package, 
  LogOut,
  ChevronDown,
  Shield
} from 'lucide-react';
import { useAuth } from '@/contexts';
import { useCart } from '@/contexts';

interface NavbarProps {
  onHome: () => void;
  onProducts: () => void;
  onCategories: () => void;
  onDeals: () => void;
  onSupport: () => void;
  onCart: () => void;
  onProfile: () => void;
  onOrders: () => void;
  onWishlist: () => void;
  onLogin: () => void;
  onRegister: () => void;
  onAdmin: () => void;
  onSearch: (query: string) => void;
}

export function Navbar({
  onHome,
  onProducts,
  onCategories,
  onDeals,
  onSupport,
  onCart,
  onProfile,
  onOrders,
  onWishlist,
  onLogin,
  onRegister,
  onAdmin,
  onSearch
}: NavbarProps) {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const { cart } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { label: 'Home', onClick: onHome },
    { label: 'Products', onClick: onProducts },
    { label: 'Categories', onClick: onCategories },
    { label: 'Deals', onClick: onDeals },
    { label: 'Support', onClick: onSupport },
  ];

  return (
    <motion.nav
      className={`navbar ${isScrolled ? 'navbar-scrolled' : ''}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="navbar-container">
        {/* Logo */}
        <motion.div 
          className="navbar-logo"
          onClick={onHome}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="logo-icon">
            <svg viewBox="0 0 40 40" className="logo-svg">
              <defs>
                <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563EB" />
                  <stop offset="100%" stopColor="#38BDF8" />
                </linearGradient>
              </defs>
              <path
                d="M20 2L38 11V29L20 38L2 29V11L20 2Z"
                fill="none"
                stroke="url(#logoGradient)"
                strokeWidth="2"
              />
              <path
                d="M20 10L30 15V25L20 30L10 25V15L20 10Z"
                fill="url(#logoGradient)"
              />
            </svg>
          </div>
          <span className="logo-text">BLUEHAT</span>
        </motion.div>

        {/* Desktop Navigation */}
        <div className="navbar-links desktop-only">
          {navLinks.map((link, index) => (
            <motion.button
              key={link.label}
              className="nav-link"
              onClick={link.onClick}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -2 }}
            >
              {link.label}
            </motion.button>
          ))}
        </div>

        {/* Right Actions */}
        <div className="navbar-actions">
          {/* Search */}
          <motion.button
            className="action-btn"
            onClick={() => setIsSearchOpen(true)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Search size={20} />
          </motion.button>

          {/* Cart */}
          <motion.button
            className="action-btn cart-btn"
            onClick={onCart}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <ShoppingCart size={20} />
            {cart.itemCount > 0 && (
              <motion.span
                className="cart-badge"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              >
                {cart.itemCount}
              </motion.span>
            )}
          </motion.button>

          {/* User Menu */}
          {isAuthenticated ? (
            <div className="user-menu-container">
              <motion.button
                className="user-menu-trigger"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                whileHover={{ scale: 1.05 }}
              >
                <img 
                  src={user?.photoURL || '/default-avatar.png'} 
                  alt={user?.displayName}
                  className="user-avatar"
                />
                <ChevronDown size={16} />
              </motion.button>

              <AnimatePresence>
                {isUserMenuOpen && (
                  <motion.div
                    className="user-dropdown"
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="dropdown-header">
                      <span className="user-name">{user?.displayName}</span>
                      <span className="user-email">{user?.email}</span>
                    </div>
                    <div className="dropdown-divider" />
                    <button className="dropdown-item" onClick={onProfile}>
                      <User size={16} />
                      <span>Profile</span>
                    </button>
                    <button className="dropdown-item" onClick={onOrders}>
                      <Package size={16} />
                      <span>My Orders</span>
                    </button>
                    <button className="dropdown-item" onClick={onWishlist}>
                      <Heart size={16} />
                      <span>Wishlist</span>
                    </button>
                    {isAdmin && (
                      <>
                        <div className="dropdown-divider" />
                        <button className="dropdown-item admin-item" onClick={onAdmin}>
                          <Shield size={16} />
                          <span>Admin Panel</span>
                        </button>
                      </>
                    )}
                    <div className="dropdown-divider" />
                    <button className="dropdown-item logout-item" onClick={logout}>
                      <LogOut size={16} />
                      <span>Logout</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="auth-buttons desktop-only">
              <motion.button
                className="btn-login"
                onClick={onLogin}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Login
              </motion.button>
              <motion.button
                className="btn-register"
                onClick={onRegister}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Register
              </motion.button>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <motion.button
            className="mobile-menu-toggle mobile-only"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            className="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            {navLinks.map((link, index) => (
              <motion.button
                key={link.label}
                className="mobile-nav-link"
                onClick={() => {
                  link.onClick();
                  setIsMobileMenuOpen(false);
                }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                {link.label}
              </motion.button>
            ))}
            {!isAuthenticated && (
              <div className="mobile-auth-buttons">
                <button className="btn-login" onClick={onLogin}>
                  Login
                </button>
                <button className="btn-register" onClick={onRegister}>
                  Register
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Modal */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            className="search-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSearchOpen(false)}
          >
            <motion.div
              className="search-container"
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              onClick={e => e.stopPropagation()}
            >
              <form onSubmit={handleSearch}>
                <Search size={24} className="search-icon" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                />
                <button type="button" className="close-search" onClick={() => setIsSearchOpen(false)}>
                  <X size={24} />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
