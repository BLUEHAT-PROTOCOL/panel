// ============================================
// BLUEHAT STORE - MOCK DATA
// ============================================

import type { 
  Product, 
  Category, 
  PaymentMethodConfig, 
  User, 
  Order, 
  Review,
  Coupon,
  Notification
} from '@/types';

// Mock Categories
export const mockCategories: Category[] = [
  {
    id: 'cat-1',
    name: 'Software & Apps',
    slug: 'software-apps',
    description: 'Premium applications and tools for productivity',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
    icon: 'Laptop',
    productCount: 1250,
    isActive: true,
    order: 1
  },
  {
    id: 'cat-2',
    name: 'Gaming',
    slug: 'gaming',
    description: 'Game accounts, credits, and in-game items',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop',
    icon: 'Gamepad2',
    productCount: 890,
    isActive: true,
    order: 2
  },
  {
    id: 'cat-3',
    name: 'Streaming',
    slug: 'streaming',
    description: 'Entertainment subscriptions for movies and music',
    image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400&h=300&fit=crop',
    icon: 'Play',
    productCount: 456,
    isActive: true,
    order: 3
  },
  {
    id: 'cat-4',
    name: 'Productivity',
    slug: 'productivity',
    description: 'Work smarter with premium productivity tools',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&h=300&fit=crop',
    icon: 'Briefcase',
    productCount: 678,
    isActive: true,
    order: 4
  },
  {
    id: 'cat-5',
    name: 'Security',
    slug: 'security',
    description: 'Protect your digital life with security tools',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400&h=300&fit=crop',
    icon: 'Shield',
    productCount: 234,
    isActive: true,
    order: 5
  },
  {
    id: 'cat-6',
    name: 'Education',
    slug: 'education',
    description: 'Learn from the best educational platforms',
    image: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=400&h=300&fit=crop',
    icon: 'GraduationCap',
    productCount: 567,
    isActive: true,
    order: 6
  },
  {
    id: 'cat-7',
    name: 'Creative',
    slug: 'creative',
    description: 'Design assets and creative tools',
    image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=400&h=300&fit=crop',
    icon: 'Palette',
    productCount: 789,
    isActive: true,
    order: 7
  }
];

// Mock Products
export const mockProducts: Product[] = [
  {
    id: 'prod-1',
    name: 'Netflix Premium 4K - 1 Bulan',
    description: 'Akun Netflix Premium dengan akses 4K UHD. Support 4 screen simultaneously. Full garansi selama masa aktif.',
    shortDescription: 'Netflix Premium 4K - 1 Bulan dengan garansi',
    price: 45000,
    salePrice: 39000,
    type: 'apps_premium',
    category: 'Streaming',
    tags: ['netflix', 'streaming', 'premium', '4k'],
    images: [
      'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=600&h=400&fit=crop',
      'https://images.unsplash.com/photo-1535016120720-40c646be5580?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=300&h=300&fit=crop',
    stock: 50,
    stockStatus: 'in_stock',
    lowStockThreshold: 10,
    sku: 'NETFLIX-1B-4K',
    rating: 4.8,
    reviewCount: 1250,
    soldCount: 8500,
    viewCount: 25000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      duration: 30,
      warrantyDays: 30
    }
  },
  {
    id: 'prod-2',
    name: 'Spotify Premium - 3 Bulan',
    description: 'Spotify Premium dengan akses unlimited skips, offline mode, dan no ads. Upgrade akun existing atau akun baru.',
    shortDescription: 'Spotify Premium 3 Bulan - No Ads',
    price: 35000,
    type: 'apps_premium',
    category: 'Streaming',
    tags: ['spotify', 'music', 'premium'],
    images: [
      'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=300&h=300&fit=crop',
    stock: 100,
    stockStatus: 'in_stock',
    lowStockThreshold: 15,
    sku: 'SPOTIFY-3B',
    rating: 4.7,
    reviewCount: 890,
    soldCount: 5600,
    viewCount: 18000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      duration: 90,
      warrantyDays: 30
    }
  },
  {
    id: 'prod-3',
    name: 'Canva Pro - 1 Tahun',
    description: 'Canva Pro dengan akses semua premium templates, brand kit, background remover, dan 1TB cloud storage.',
    shortDescription: 'Canva Pro 1 Tahun - Full Features',
    price: 150000,
    salePrice: 129000,
    type: 'apps_premium',
    category: 'Creative',
    tags: ['canva', 'design', 'pro', 'creative'],
    images: [
      'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=300&h=300&fit=crop',
    stock: 30,
    stockStatus: 'in_stock',
    lowStockThreshold: 5,
    sku: 'CANVA-1Y-PRO',
    rating: 4.9,
    reviewCount: 650,
    soldCount: 3200,
    viewCount: 12000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      duration: 365,
      warrantyDays: 30
    }
  },
  {
    id: 'prod-4',
    name: 'Steam Wallet Code - $20',
    description: 'Steam Wallet Code $20 USD. Redeem langsung di akun Steam Anda. Instant delivery.',
    shortDescription: 'Steam Wallet $20 - Instant Code',
    price: 310000,
    type: 'redeem_code',
    category: 'Gaming',
    tags: ['steam', 'gaming', 'wallet', 'code'],
    images: [
      'https://images.unsplash.com/photo-1552820728-8b83bb6b2b0a?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1552820728-8b83bb6b2b0a?w=300&h=300&fit=crop',
    stock: 200,
    stockStatus: 'in_stock',
    lowStockThreshold: 20,
    sku: 'STEAM-20USD',
    rating: 4.9,
    reviewCount: 2100,
    soldCount: 15000,
    viewCount: 35000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate'
    }
  },
  {
    id: 'prod-5',
    name: 'Mobile Legends Diamonds - 1400',
    description: '1400 Diamonds Mobile Legends. Top up instant ke akun Anda. Support all payment methods.',
    shortDescription: 'MLBB 1400 Diamonds - Instant Top Up',
    price: 280000,
    salePrice: 265000,
    type: 'redeem_code',
    category: 'Gaming',
    tags: ['mobile legends', 'gaming', 'diamonds', 'mlbb'],
    images: [
      'https://images.unsplash.com/photo-1542751110-97427bbecf20?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1542751110-97427bbecf20?w=300&h=300&fit=crop',
    stock: 500,
    stockStatus: 'in_stock',
    lowStockThreshold: 50,
    sku: 'MLBB-1400',
    rating: 4.6,
    reviewCount: 3200,
    soldCount: 28000,
    viewCount: 65000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-01-05'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate'
    }
  },
  {
    id: 'prod-6',
    name: 'Adobe Creative Cloud - 1 Bulan',
    description: 'Adobe Creative Cloud All Apps termasuk Photoshop, Illustrator, Premiere Pro, After Effects, dan 20+ apps lainnya.',
    shortDescription: 'Adobe CC All Apps - 1 Bulan',
    price: 350000,
    type: 'license_key',
    category: 'Creative',
    tags: ['adobe', 'creative', 'photoshop', 'design'],
    images: [
      'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=300&h=300&fit=crop',
    stock: 25,
    stockStatus: 'in_stock',
    lowStockThreshold: 5,
    sku: 'ADOBE-CC-1M',
    rating: 4.8,
    reviewCount: 420,
    soldCount: 1800,
    viewCount: 8000,
    isFeatured: false,
    isActive: true,
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      licensePrefix: 'ADB-CC'
    }
  },
  {
    id: 'prod-7',
    name: 'YouTube Premium - 1 Bulan',
    description: 'YouTube Premium dengan no ads, background play, dan YouTube Music Premium included.',
    shortDescription: 'YouTube Premium + Music - 1 Bulan',
    price: 25000,
    salePrice: 22000,
    type: 'apps_premium',
    category: 'Streaming',
    tags: ['youtube', 'premium', 'music', 'streaming'],
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=300&fit=crop',
    stock: 80,
    stockStatus: 'in_stock',
    lowStockThreshold: 10,
    sku: 'YT-PREM-1M',
    rating: 4.7,
    reviewCount: 780,
    soldCount: 4500,
    viewCount: 15000,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-01-25'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      duration: 30,
      warrantyDays: 30
    }
  },
  {
    id: 'prod-8',
    name: 'ChatGPT Plus - 1 Bulan',
    description: 'ChatGPT Plus dengan GPT-4 access, faster response, dan priority access during peak times.',
    shortDescription: 'ChatGPT Plus - GPT-4 Access',
    price: 350000,
    type: 'apps_premium',
    category: 'Productivity',
    tags: ['chatgpt', 'ai', 'gpt4', 'productivity'],
    images: [
      'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop'
    ],
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=300&h=300&fit=crop',
    stock: 40,
    stockStatus: 'in_stock',
    lowStockThreshold: 8,
    sku: 'CHATGPT-PLUS-1M',
    rating: 4.9,
    reviewCount: 560,
    soldCount: 2100,
    viewCount: 9500,
    isFeatured: true,
    isActive: true,
    createdAt: new Date('2024-02-15'),
    updatedAt: new Date('2024-03-01'),
    digitalDelivery: {
      autoDelivery: true,
      deliveryMethod: 'immediate',
      duration: 30,
      warrantyDays: 30
    }
  }
];

// Payment Methods Configuration
export const paymentMethods: PaymentMethodConfig[] = [
  {
    id: 'qris',
    name: 'QRIS',
    icon: 'QrCode',
    category: 'qris',
    instructions: [
      'Buka aplikasi e-wallet atau mobile banking Anda',
      'Pilih menu Scan QRIS',
      'Scan kode QR yang ditampilkan',
      'Konfirmasi jumlah pembayaran',
      'Selesaikan pembayaran'
    ],
    qrImage: '/payment-qr/qris.png',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: 'Instant'
  },
  {
    id: 'dana',
    name: 'DANA',
    icon: 'Wallet',
    category: 'ewallet',
    instructions: [
      'Buka aplikasi DANA Anda',
      'Kirim pembayaran ke nomor: 0812-3456-7890',
      'Atas Nama: BLUEHAT STORE',
      'Masukkan jumlah yang tepat',
      'Screenshot bukti pembayaran'
    ],
    accountNumber: '0812-3456-7890',
    accountName: 'BLUEHAT STORE',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '1-5 menit'
  },
  {
    id: 'gopay',
    name: 'GoPay',
    icon: 'Wallet',
    category: 'ewallet',
    instructions: [
      'Buka aplikasi Gojek/GoPay Anda',
      'Kirim pembayaran ke nomor: 0812-3456-7890',
      'Atas Nama: BLUEHAT STORE',
      'Masukkan jumlah yang tepat',
      'Screenshot bukti pembayaran'
    ],
    accountNumber: '0812-3456-7890',
    accountName: 'BLUEHAT STORE',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '1-5 menit'
  },
  {
    id: 'ovo',
    name: 'OVO',
    icon: 'Wallet',
    category: 'ewallet',
    instructions: [
      'Buka aplikasi OVO Anda',
      'Kirim pembayaran ke nomor: 0812-3456-7890',
      'Atas Nama: BLUEHAT STORE',
      'Masukkan jumlah yang tepat',
      'Screenshot bukti pembayaran'
    ],
    accountNumber: '0812-3456-7890',
    accountName: 'BLUEHAT STORE',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '1-5 menit'
  },
  {
    id: 'linkaja',
    name: 'LinkAja',
    icon: 'Wallet',
    category: 'ewallet',
    instructions: [
      'Buka aplikasi LinkAja Anda',
      'Kirim pembayaran ke nomor: 0812-3456-7890',
      'Atas Nama: BLUEHAT STORE',
      'Masukkan jumlah yang tepat',
      'Screenshot bukti pembayaran'
    ],
    accountNumber: '0812-3456-7890',
    accountName: 'BLUEHAT STORE',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '1-5 menit'
  },
  {
    id: 'bca',
    name: 'Transfer BCA',
    icon: 'Building2',
    category: 'bank',
    instructions: [
      'Login ke BCA Mobile/Internet Banking',
      'Pilih Transfer ke Rekening BCA',
      'Nomor Rekening: 123-456-7890',
      'Atas Nama: PT BLUEHAT DIGITAL',
      'Masukkan jumlah yang tepat',
      'Screenshot/simpan bukti transfer'
    ],
    accountNumber: '123-456-7890',
    accountName: 'PT BLUEHAT DIGITAL',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '5-15 menit'
  },
  {
    id: 'mandiri',
    name: 'Transfer Mandiri',
    icon: 'Building2',
    category: 'bank',
    instructions: [
      'Login ke Livin\' by Mandiri',
      'Pilih Transfer ke Rekening Mandiri',
      'Nomor Rekening: 098-765-4321',
      'Atas Nama: PT BLUEHAT DIGITAL',
      'Masukkan jumlah yang tepat',
      'Screenshot/simpan bukti transfer'
    ],
    accountNumber: '098-765-4321',
    accountName: 'PT BLUEHAT DIGITAL',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '5-15 menit'
  },
  {
    id: 'bni',
    name: 'Transfer BNI',
    icon: 'Building2',
    category: 'bank',
    instructions: [
      'Login ke BNI Mobile Banking',
      'Pilih Transfer ke Rekening BNI',
      'Nomor Rekening: 456-789-0123',
      'Atas Nama: PT BLUEHAT DIGITAL',
      'Masukkan jumlah yang tepat',
      'Screenshot/simpan bukti transfer'
    ],
    accountNumber: '456-789-0123',
    accountName: 'PT BLUEHAT DIGITAL',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '5-15 menit'
  },
  {
    id: 'bri',
    name: 'Transfer BRI',
    icon: 'Building2',
    category: 'bank',
    instructions: [
      'Login ke BRImo',
      'Pilih Transfer ke Rekening BRI',
      'Nomor Rekening: 789-012-3456',
      'Atas Nama: PT BLUEHAT DIGITAL',
      'Masukkan jumlah yang tepat',
      'Screenshot/simpan bukti transfer'
    ],
    accountNumber: '789-012-3456',
    accountName: 'PT BLUEHAT DIGITAL',
    isActive: true,
    fee: 0,
    feeType: 'fixed',
    minAmount: 10000,
    processingTime: '5-15 menit'
  }
];

// Mock User
export const mockUser: User = {
  id: 'user-1',
  email: 'customer@bluehat.store',
  displayName: 'John Doe',
  photoURL: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
  role: 'customer',
  phone: '0812-3456-7890',
  addresses: [
    {
      id: 'addr-1',
      label: 'Rumah',
      recipientName: 'John Doe',
      phone: '0812-3456-7890',
      street: 'Jl. Sudirman No. 123',
      city: 'Jakarta Selatan',
      province: 'DKI Jakarta',
      postalCode: '12190',
      isDefault: true
    }
  ],
  createdAt: new Date('2024-01-01'),
  updatedAt: new Date('2024-03-01'),
  loyaltyPoints: 1250,
  membershipLevel: 'silver',
  emailVerified: true
};

// Mock Orders
export const mockOrders: Order[] = [
  {
    id: 'order-1',
    orderNumber: 'BHS-20240301-001',
    userId: 'user-1',
    user: mockUser,
    items: [
      {
        id: 'item-1',
        productId: 'prod-1',
        product: mockProducts[0],
        quantity: 1,
        price: 39000
      }
    ],
    status: 'completed',
    statusHistory: [
      { status: 'pending', note: 'Order created', createdAt: new Date('2024-03-01T10:00:00'), createdBy: 'system' },
      { status: 'awaiting_confirmation', note: 'Payment proof uploaded', createdAt: new Date('2024-03-01T10:05:00'), createdBy: 'system' },
      { status: 'confirmed', note: 'Payment confirmed by admin', createdAt: new Date('2024-03-01T10:30:00'), createdBy: 'admin' },
      { status: 'completed', note: 'Order completed', createdAt: new Date('2024-03-01T10:35:00'), createdBy: 'system' }
    ],
    shippingAddress: mockUser.addresses[0],
    billingAddress: mockUser.addresses[0],
    subtotal: 39000,
    shippingCost: 0,
    tax: 0,
    discount: 0,
    total: 39000,
    paymentMethod: 'dana',
    paymentStatus: 'confirmed',
    createdAt: new Date('2024-03-01T10:00:00'),
    updatedAt: new Date('2024-03-01T10:35:00')
  },
  {
    id: 'order-2',
    orderNumber: 'BHS-20240302-002',
    userId: 'user-1',
    user: mockUser,
    items: [
      {
        id: 'item-2',
        productId: 'prod-4',
        product: mockProducts[3],
        quantity: 2,
        price: 310000
      }
    ],
    status: 'awaiting_confirmation',
    statusHistory: [
      { status: 'pending', note: 'Order created', createdAt: new Date('2024-03-02T14:00:00'), createdBy: 'system' },
      { status: 'awaiting_confirmation', note: 'Payment proof uploaded', createdAt: new Date('2024-03-02T14:10:00'), createdBy: 'system' }
    ],
    shippingAddress: mockUser.addresses[0],
    billingAddress: mockUser.addresses[0],
    subtotal: 620000,
    shippingCost: 0,
    tax: 0,
    discount: 0,
    total: 620000,
    paymentMethod: 'bca',
    paymentStatus: 'awaiting_confirmation',
    createdAt: new Date('2024-03-02T14:00:00'),
    updatedAt: new Date('2024-03-02T14:10:00')
  }
];

// Mock Reviews
export const mockReviews: Review[] = [
  {
    id: 'review-1',
    productId: 'prod-1',
    product: mockProducts[0],
    userId: 'user-1',
    user: mockUser,
    orderId: 'order-1',
    rating: 5,
    title: 'Netflix berfungsi dengan baik!',
    content: 'Akun Netflix berfungsi dengan baik, sudah 2 minggu tidak ada masalah. Garansi juga responsif.',
    isVerified: true,
    helpfulCount: 45,
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date('2024-03-05')
  },
  {
    id: 'review-2',
    productId: 'prod-1',
    product: mockProducts[0],
    userId: 'user-2',
    user: { ...mockUser, id: 'user-2', displayName: 'Jane Smith', photoURL: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face' },
    orderId: 'order-3',
    rating: 4,
    title: 'Bagus tapi ada kendala awal',
    content: 'Awalnya ada kendala login tapi customer service cepat membantu. Sekarang sudah normal.',
    isVerified: true,
    helpfulCount: 23,
    createdAt: new Date('2024-03-03'),
    updatedAt: new Date('2024-03-03')
  }
];

// Mock Coupons
export const mockCoupons: Coupon[] = [
  {
    id: 'coupon-1',
    code: 'BLUEHAT10',
    description: 'Diskon 10% untuk pembelian pertama',
    type: 'percentage',
    value: 10,
    minOrderAmount: 50000,
    maxDiscount: 50000,
    usageLimit: 100,
    usageCount: 45,
    userLimit: 1,
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
    isActive: true
  },
  {
    id: 'coupon-2',
    code: 'WELCOME25K',
    description: 'Potongan Rp 25.000',
    type: 'fixed',
    value: 25000,
    minOrderAmount: 100000,
    usageLimit: 200,
    usageCount: 89,
    userLimit: 1,
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
    isActive: true
  }
];

// Mock Notifications
export const mockNotifications: Notification[] = [
  {
    id: 'notif-1',
    userId: 'user-1',
    type: 'order_confirmed',
    title: 'Pesanan Dikonfirmasi',
    message: 'Pesanan BHS-20240301-001 telah dikonfirmasi dan sedang diproses.',
    data: { orderId: 'order-1' },
    isRead: true,
    createdAt: new Date('2024-03-01T10:30:00')
  },
  {
    id: 'notif-2',
    userId: 'user-1',
    type: 'payment_confirmed',
    title: 'Pembayaran Dikonfirmasi',
    message: 'Pembayaran untuk pesanan BHS-20240301-001 telah dikonfirmasi.',
    data: { orderId: 'order-1' },
    isRead: true,
    createdAt: new Date('2024-03-01T10:30:00')
  },
  {
    id: 'notif-3',
    userId: 'user-1',
    type: 'order_created',
    title: 'Pesanan Baru',
    message: 'Pesanan BHS-20240302-002 menunggu pembayaran.',
    data: { orderId: 'order-2' },
    isRead: false,
    createdAt: new Date('2024-03-02T14:00:00')
  }
];

// Admin Dashboard Stats
export const mockAdminStats = {
  totalOrders: 15420,
  totalRevenue: 2457800000,
  totalCustomers: 8750,
  totalProducts: 5420,
  pendingOrders: 45,
  pendingPayments: 23,
  todayOrders: 156,
  todayRevenue: 24500000,
  lowStockProducts: 12
};

// Sales Chart Data
export const mockSalesChartData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  orders: [1200, 1350, 1480, 1620, 1750, 1890, 2100, 2250, 2400, 2580, 2750, 2900],
  revenue: [180000000, 202500000, 222000000, 243000000, 262500000, 283500000, 315000000, 337500000, 360000000, 387000000, 412500000, 435000000]
};
