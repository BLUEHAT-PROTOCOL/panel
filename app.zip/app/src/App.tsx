// ============================================
// BLUEHAT STORE - MAIN APP COMPONENT
// ============================================

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AuthProvider, 
  CartProvider, 
  OrderProvider, 
  NotificationProvider 
} from '@/contexts';
import { 
  Navbar, 
  Footer, 
  CartDrawer,
  NotificationToast,
  LoginModal,
  RegisterModal
} from '@/components/ui';
import { 
  HeroSection,
  CategoriesSection,
  FeaturedProductsSection,
  WhyChooseUsSection,
  HowItWorksSection,
  TestimonialsSection,
  StatsSection,
  CTASection
} from '@/sections';
import { 
  ProductDetailPage,
  CartPage,
  CheckoutPage,
  PaymentPage,
  PaymentConfirmPage,
  OrderSuccessPage,
  OrderHistoryPage,
  OrderDetailPage,
  ProfilePage,
  WishlistPage,
  SearchPage,
  CategoryPage,
  AdminDashboardPage,
  AdminProductsPage,
  AdminOrdersPage,
  AdminPaymentsPage,
  AdminCustomersPage
} from '@/pages';
import './App.css';

// Page type for navigation
type PageType = 
  | 'home' 
  | 'product' 
  | 'cart' 
  | 'checkout' 
  | 'payment' 
  | 'payment-confirm'
  | 'order-success'
  | 'orders'
  | 'order-detail'
  | 'profile'
  | 'wishlist'
  | 'search'
  | 'category'
  | 'admin-dashboard'
  | 'admin-products'
  | 'admin-orders'
  | 'admin-payments'
  | 'admin-customers';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [pageParams, setPageParams] = useState<Record<string, any>>({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate initial loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  // Navigation functions
  const navigateTo = (page: PageType, params?: Record<string, any>) => {
    setPageParams(params || {});
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goHome = () => navigateTo('home');
  const goToProduct = (productId: string) => navigateTo('product', { productId });
  const goToCart = () => setIsCartOpen(true);
  const goToCheckout = () => navigateTo('checkout');
  const goToPayment = (orderId: string) => navigateTo('payment', { orderId });
  const goToPaymentConfirm = (orderId: string) => navigateTo('payment-confirm', { orderId });
  const goToOrderSuccess = (orderId: string) => navigateTo('order-success', { orderId });
  const goToOrders = () => navigateTo('orders');
  const goToOrderDetail = (orderId: string) => navigateTo('order-detail', { orderId });
  const goToProfile = () => navigateTo('profile');
  const goToWishlist = () => navigateTo('wishlist');
  const goToSearch = (query?: string) => navigateTo('search', { query });
  const goToCategory = (categoryId: string) => navigateTo('category', { categoryId });
  const goToAdmin = () => navigateTo('admin-dashboard');

  // Loading screen
  if (isLoading) {
    return (
      <div className="loading-screen">
        <motion.div 
          className="loading-logo"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="loading-icon">
            <svg viewBox="0 0 100 100" className="loading-svg">
              <defs>
                <linearGradient id="loadingGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563EB" />
                  <stop offset="50%" stopColor="#38BDF8" />
                  <stop offset="100%" stopColor="#22D3EE" />
                </linearGradient>
              </defs>
              <circle 
                cx="50" 
                cy="50" 
                r="40" 
                fill="none" 
                stroke="url(#loadingGradient)" 
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray="200"
                strokeDashoffset="200"
                className="loading-circle"
              />
            </svg>
          </div>
          <motion.h1 
            className="loading-text"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            BLUEHAT STORE
          </motion.h1>
          <motion.p
            className="loading-subtext"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Loading Premium Digital Marketplace...
          </motion.p>
        </motion.div>
      </div>
    );
  }

  // Render current page
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <main className="main-content">
            <HeroSection onExplore={() => navigateTo('search')} />
            <CategoriesSection onCategoryClick={goToCategory} />
            <FeaturedProductsSection onProductClick={goToProduct} />
            <WhyChooseUsSection />
            <HowItWorksSection />
            <TestimonialsSection />
            <StatsSection />
            <CTASection onShopNow={() => navigateTo('search')} />
          </main>
        );
      
      case 'product':
        return (
          <ProductDetailPage 
            productId={pageParams.productId}
            onBack={goHome}
            onAddToCart={() => setIsCartOpen(true)}
          />
        );
      
      case 'cart':
        return <CartPage onCheckout={goToCheckout} onContinueShopping={goHome} />;
      
      case 'checkout':
        return (
          <CheckoutPage 
            onBack={() => navigateTo('home')}
            onOrderComplete={(orderId) => goToPayment(orderId)}
          />
        );
      
      case 'payment':
        return (
          <PaymentPage 
            orderId={pageParams.orderId}
            onBack={goToOrders}
            onUploadProof={(orderId) => goToPaymentConfirm(orderId)}
          />
        );
      
      case 'payment-confirm':
        return (
          <PaymentConfirmPage 
            orderId={pageParams.orderId}
            onBack={() => goToPayment(pageParams.orderId)}
            onSuccess={(orderId) => goToOrderSuccess(orderId)}
          />
        );
      
      case 'order-success':
        return (
          <OrderSuccessPage 
            orderId={pageParams.orderId}
            onViewOrder={goToOrderDetail}
            onContinueShopping={goHome}
          />
        );
      
      case 'orders':
        return (
          <OrderHistoryPage 
            onBack={goHome}
            onViewOrder={goToOrderDetail}
          />
        );
      
      case 'order-detail':
        return (
          <OrderDetailPage 
            orderId={pageParams.orderId}
            onBack={goToOrders}
          />
        );
      
      case 'profile':
        return <ProfilePage onBack={goHome} />;
      
      case 'wishlist':
        return (
          <WishlistPage 
            onBack={goHome}
            onProductClick={goToProduct}
          />
        );
      
      case 'search':
        return (
          <SearchPage 
            initialQuery={pageParams.query}
            onProductClick={goToProduct}
            onBack={goHome}
          />
        );
      
      case 'category':
        return (
          <CategoryPage 
            categoryId={pageParams.categoryId}
            onProductClick={goToProduct}
            onBack={goHome}
          />
        );
      
      case 'admin-dashboard':
        return <AdminDashboardPage />;
      
      case 'admin-products':
        return <AdminProductsPage />;
      
      case 'admin-orders':
        return <AdminOrdersPage />;
      
      case 'admin-payments':
        return <AdminPaymentsPage />;
      
      case 'admin-customers':
        return <AdminCustomersPage />;
      
      default:
        return null;
    }
  };

  return (
    <div className="app">
      <Navbar 
        onHome={goHome}
        onProducts={() => navigateTo('search')}
        onCategories={() => navigateTo('search')}
        onDeals={() => navigateTo('search')}
        onSupport={() => {}}
        onCart={goToCart}
        onProfile={goToProfile}
        onOrders={goToOrders}
        onWishlist={goToWishlist}
        onLogin={() => setIsLoginOpen(true)}
        onRegister={() => setIsRegisterOpen(true)}
        onAdmin={goToAdmin}
        onSearch={goToSearch}
      />
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="page-container"
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
      
      {currentPage === 'home' && <Footer onNavigate={navigateTo} />}
      
      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={() => {
          setIsCartOpen(false);
          goToCheckout();
        }}
      />
      
      <LoginModal 
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onRegister={() => {
          setIsLoginOpen(false);
          setIsRegisterOpen(true);
        }}
        onLoginSuccess={() => setIsLoginOpen(false)}
      />
      
      <RegisterModal 
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        onLogin={() => {
          setIsRegisterOpen(false);
          setIsLoginOpen(true);
        }}
        onRegisterSuccess={() => setIsRegisterOpen(false)}
      />
      
      <NotificationToast />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <OrderProvider>
          <NotificationProvider>
            <AppContent />
          </NotificationProvider>
        </OrderProvider>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
