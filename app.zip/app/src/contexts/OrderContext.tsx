// ============================================
// BLUEHAT STORE - ORDER CONTEXT
// ============================================

import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Order, OrderStatus, Payment, PaymentProofData, Address, Product } from '@/types';
import { mockOrders } from '@/data/mockData';

interface OrderContextType {
  orders: Order[];
  pendingPayments: Payment[];
  createOrder: (data: CreateOrderData) => Promise<Order>;
  uploadPaymentProof: (orderId: string, proofImage: string, proofData: PaymentProofData) => Promise<void>;
  confirmPayment: (paymentId: string) => Promise<void>;
  rejectPayment: (paymentId: string, reason: string) => Promise<void>;
  cancelOrder: (orderId: string, reason?: string) => Promise<void>;
  getOrderById: (orderId: string) => Order | undefined;
  getOrdersByStatus: (status: OrderStatus) => Order[];
  getUserOrders: (userId: string) => Order[];
  deliverDigitalProduct: (orderId: string, itemId: string, data: any) => Promise<void>;
}

interface CreateOrderData {
  userId: string;
  items: { product: Product; quantity: number; variant?: string }[];
  shippingAddress: Address;
  billingAddress: Address;
  paymentMethod: string;
  couponCode?: string;
  notes?: string;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

// Mock payments data
const mockPayments: Payment[] = [
  {
    id: 'pay-1',
    orderId: 'order-2',
    order: mockOrders[1],
    method: 'bca',
    amount: 620000,
    fee: 0,
    total: 620000,
    status: 'awaiting_confirmation',
    expiryDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [pendingPayments, setPendingPayments] = useState<Payment[]>(mockPayments);

  const createOrder = useCallback(async (data: CreateOrderData): Promise<Order> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const orderNumber = `BHS-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(orders.length + 1).padStart(3, '0')}`;
    
    const subtotal = data.items.reduce((sum, item) => 
      sum + ((item.product.salePrice || item.product.price) * item.quantity), 0
    );
    
    const newOrder: Order = {
      id: `order-${Date.now()}`,
      orderNumber,
      userId: data.userId,
      user: {} as any, // Will be populated from auth
      items: data.items.map((item, index) => ({
        id: `item-${Date.now()}-${index}`,
        productId: item.product.id,
        product: item.product,
        quantity: item.quantity,
        price: item.product.salePrice || item.product.price,
        variant: item.variant
      })),
      status: 'awaiting_payment',
      statusHistory: [{
        status: 'pending',
        note: 'Order created',
        createdAt: new Date(),
        createdBy: 'system'
      }],
      shippingAddress: data.shippingAddress,
      billingAddress: data.billingAddress,
      subtotal,
      shippingCost: 0,
      tax: 0,
      discount: 0,
      total: subtotal,
      couponCode: data.couponCode,
      notes: data.notes,
      paymentMethod: data.paymentMethod as any,
      paymentStatus: 'pending',
      createdAt: new Date(),
      updatedAt: new Date(),
      expiredAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
    };
    
    setOrders(prev => [newOrder, ...prev]);
    
    // Create associated payment
    const newPayment: Payment = {
      id: `pay-${Date.now()}`,
      orderId: newOrder.id,
      order: newOrder,
      method: data.paymentMethod as any,
      amount: subtotal,
      fee: 0,
      total: subtotal,
      status: 'pending',
      expiryDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    setPendingPayments(prev => [newPayment, ...prev]);
    
    return newOrder;
  }, [orders.length]);

  const uploadPaymentProof = useCallback(async (orderId: string, proofImage: string, proofData: PaymentProofData) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Update order status
    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'awaiting_confirmation',
          statusHistory: [
            ...order.statusHistory,
            {
              status: 'awaiting_confirmation',
              note: 'Payment proof uploaded',
              createdAt: new Date(),
              createdBy: 'system'
            }
          ],
          updatedAt: new Date()
        };
      }
      return order;
    }));
    
    // Update payment
    setPendingPayments(prev => prev.map(payment => {
      if (payment.orderId === orderId) {
        return {
          ...payment,
          proofImage,
          proofData,
          status: 'awaiting_confirmation',
          updatedAt: new Date()
        };
      }
      return payment;
    }));
  }, []);

  const confirmPayment = useCallback(async (paymentId: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const payment = pendingPayments.find(p => p.id === paymentId);
    if (!payment) return;
    
    // Update payment status
    setPendingPayments(prev => prev.map(p => {
      if (p.id === paymentId) {
        return {
          ...p,
          status: 'confirmed',
          confirmedAt: new Date(),
          confirmedBy: 'admin',
          updatedAt: new Date()
        };
      }
      return p;
    }));
    
    // Update order status
    setOrders(prev => prev.map(order => {
      if (order.id === payment.orderId) {
        return {
          ...order,
          status: 'confirmed',
          paymentStatus: 'confirmed',
          statusHistory: [
            ...order.statusHistory,
            {
              status: 'confirmed',
              note: 'Payment confirmed by admin',
              createdAt: new Date(),
              createdBy: 'admin'
            }
          ],
          updatedAt: new Date()
        };
      }
      return order;
    }));
  }, [pendingPayments]);

  const rejectPayment = useCallback(async (paymentId: string, reason: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const payment = pendingPayments.find(p => p.id === paymentId);
    if (!payment) return;
    
    // Update payment status
    setPendingPayments(prev => prev.map(p => {
      if (p.id === paymentId) {
        return {
          ...p,
          status: 'rejected',
          rejectionReason: reason,
          updatedAt: new Date()
        };
      }
      return p;
    }));
    
    // Update order status
    setOrders(prev => prev.map(order => {
      if (order.id === payment.orderId) {
        return {
          ...order,
          status: 'pending',
          paymentStatus: 'rejected',
          statusHistory: [
            ...order.statusHistory,
            {
              status: 'pending',
              note: `Payment rejected: ${reason}`,
              createdAt: new Date(),
              createdBy: 'admin'
            }
          ],
          updatedAt: new Date()
        };
      }
      return order;
    }));
  }, [pendingPayments]);

  const cancelOrder = useCallback(async (orderId: string, reason?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'cancelled',
          statusHistory: [
            ...order.statusHistory,
            {
              status: 'cancelled',
              note: reason || 'Order cancelled by customer',
              createdAt: new Date(),
              createdBy: 'customer'
            }
          ],
          updatedAt: new Date()
        };
      }
      return order;
    }));
  }, []);

  const getOrderById = useCallback((orderId: string) => {
    return orders.find(order => order.id === orderId);
  }, [orders]);

  const getOrdersByStatus = useCallback((status: OrderStatus) => {
    return orders.filter(order => order.status === status);
  }, [orders]);

  const getUserOrders = useCallback((userId: string) => {
    return orders.filter(order => order.userId === userId);
  }, [orders]);

  const deliverDigitalProduct = useCallback(async (orderId: string, itemId: string, data: any) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          items: order.items.map(item => {
            if (item.id === itemId) {
              return {
                ...item,
                deliveredData: {
                  type: data.type,
                  data: data.content,
                  deliveredAt: new Date()
                }
              };
            }
            return item;
          }),
          status: 'completed',
          statusHistory: [
            ...order.statusHistory,
            {
              status: 'completed',
              note: 'Digital product delivered',
              createdAt: new Date(),
              createdBy: 'system'
            }
          ],
          updatedAt: new Date()
        };
      }
      return order;
    }));
  }, []);

  const value: OrderContextType = {
    orders,
    pendingPayments,
    createOrder,
    uploadPaymentProof,
    confirmPayment,
    rejectPayment,
    cancelOrder,
    getOrderById,
    getOrdersByStatus,
    getUserOrders,
    deliverDigitalProduct
  };

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
}

export function useOrder() {
  const context = useContext(OrderContext);
  if (context === undefined) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
}
