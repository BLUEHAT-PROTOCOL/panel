// ============================================
// BLUEHAT STORE - CART CONTEXT
// ============================================

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Cart, CartItem, Product, Coupon } from '@/types';
import { mockCoupons } from '@/data/mockData';

interface CartContextType {
  cart: Cart;
  addToCart: (product: Product, quantity?: number, variant?: string) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
  isInCart: (productId: string) => boolean;
  getCartItemCount: (productId: string) => number;
}

const defaultCart: Cart = {
  items: [],
  subtotal: 0,
  discount: 0,
  tax: 0,
  total: 0,
  itemCount: 0
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<Cart>(defaultCart);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('bluehat_cart');
    if (savedCart) {
      try {
        const parsed = JSON.parse(savedCart);
        setCart(parsed);
      } catch (error) {
        console.error('Error parsing cart:', error);
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('bluehat_cart', JSON.stringify(cart));
  }, [cart]);

  // Calculate cart totals
  const calculateTotals = useCallback((items: CartItem[], coupon: Coupon | null): Cart => {
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
    
    // Calculate discount
    let discount = 0;
    if (coupon) {
      if (coupon.type === 'percentage') {
        discount = (subtotal * coupon.value) / 100;
        if (coupon.maxDiscount && discount > coupon.maxDiscount) {
          discount = coupon.maxDiscount;
        }
      } else {
        discount = coupon.value;
      }
    }
    
    // Tax calculation (0% for digital products in Indonesia)
    const tax = 0;
    
    const total = Math.max(0, subtotal - discount + tax);
    
    return {
      items,
      subtotal,
      discount,
      tax,
      total,
      itemCount,
      couponCode: coupon?.code
    };
  }, []);

  const addToCart = useCallback((product: Product, quantity: number = 1, variant?: string) => {
    setCart(prevCart => {
      // Check if item already exists in cart
      const existingItemIndex = prevCart.items.findIndex(
        item => item.productId === product.id && item.variant === variant
      );
      
      let newItems: CartItem[];
      
      if (existingItemIndex >= 0) {
        // Update existing item
        newItems = [...prevCart.items];
        newItems[existingItemIndex] = {
          ...newItems[existingItemIndex],
          quantity: newItems[existingItemIndex].quantity + quantity
        };
      } else {
        // Add new item
        const newItem: CartItem = {
          id: `cart-${Date.now()}`,
          productId: product.id,
          product,
          quantity,
          variant,
          price: product.salePrice || product.price,
          addedAt: new Date()
        };
        newItems = [...prevCart.items, newItem];
      }
      
      return calculateTotals(newItems, appliedCoupon);
    });
  }, [appliedCoupon, calculateTotals]);

  const removeFromCart = useCallback((itemId: string) => {
    setCart(prevCart => {
      const newItems = prevCart.items.filter(item => item.id !== itemId);
      return calculateTotals(newItems, appliedCoupon);
    });
  }, [appliedCoupon, calculateTotals]);

  const updateQuantity = useCallback((itemId: string, quantity: number) => {
    if (quantity < 1) return;
    
    setCart(prevCart => {
      const newItems = prevCart.items.map(item =>
        item.id === itemId ? { ...item, quantity } : item
      );
      return calculateTotals(newItems, appliedCoupon);
    });
  }, [appliedCoupon, calculateTotals]);

  const clearCart = useCallback(() => {
    setCart(defaultCart);
    setAppliedCoupon(null);
  }, []);

  const applyCoupon = useCallback(async (code: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const coupon = mockCoupons.find(c => c.code.toUpperCase() === code.toUpperCase());
    
    if (!coupon) {
      return false;
    }
    
    if (!coupon.isActive) {
      return false;
    }
    
    if (new Date() > coupon.endDate) {
      return false;
    }
    
    if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
      return false;
    }
    
    if (coupon.minOrderAmount && cart.subtotal < coupon.minOrderAmount) {
      return false;
    }
    
    setAppliedCoupon(coupon);
    setCart(prevCart => calculateTotals(prevCart.items, coupon));
    return true;
  }, [cart.subtotal, calculateTotals]);

  const removeCoupon = useCallback(() => {
    setAppliedCoupon(null);
    setCart(prevCart => calculateTotals(prevCart.items, null));
  }, [calculateTotals]);

  const isInCart = useCallback((productId: string): boolean => {
    return cart.items.some(item => item.productId === productId);
  }, [cart.items]);

  const getCartItemCount = useCallback((productId: string): number => {
    const item = cart.items.find(item => item.productId === productId);
    return item?.quantity || 0;
  }, [cart.items]);

  const value: CartContextType = {
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    applyCoupon,
    removeCoupon,
    isInCart,
    getCartItemCount
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
