// ============================================
// BLUEHAT STORE - AUTH CONTEXT
// ============================================

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { User } from '@/types';
import { mockUser } from '@/data/mockData';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithFacebook: () => Promise<void>;
  register: (email: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  addAddress: (address: Omit<User['addresses'][0], 'id'>) => Promise<void>;
  updateAddress: (addressId: string, data: Partial<User['addresses'][0]>) => Promise<void>;
  deleteAddress: (addressId: string) => Promise<void>;
  setDefaultAddress: (addressId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate auth state check
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check localStorage for saved session
        const savedUser = localStorage.getItem('bluehat_user');
        if (savedUser) {
          setUser(JSON.parse(savedUser));
        }
      } catch (error) {
        console.error('Auth check error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo, accept any email/password
      const loggedInUser = {
        ...mockUser,
        email,
        displayName: email.split('@')[0]
      };
      
      setUser(loggedInUser);
      localStorage.setItem('bluehat_user', JSON.stringify(loggedInUser));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const loginWithGoogle = useCallback(async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setUser(mockUser);
      localStorage.setItem('bluehat_user', JSON.stringify(mockUser));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const loginWithFacebook = useCallback(async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setUser(mockUser);
      localStorage.setItem('bluehat_user', JSON.stringify(mockUser));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const register = useCallback(async (email: string, password: string, displayName: string) => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newUser: User = {
        ...mockUser,
        id: `user-${Date.now()}`,
        email,
        displayName,
        addresses: [],
        loyaltyPoints: 0,
        membershipLevel: 'bronze',
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      setUser(newUser);
      localStorage.setItem('bluehat_user', JSON.stringify(newUser));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setUser(null);
      localStorage.removeItem('bluehat_user');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateProfile = useCallback(async (data: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...data, updatedAt: new Date() };
    setUser(updatedUser);
    localStorage.setItem('bluehat_user', JSON.stringify(updatedUser));
  }, [user]);

  const addAddress = useCallback(async (address: Omit<User['addresses'][0], 'id'>) => {
    if (!user) return;
    
    const newAddress = {
      ...address,
      id: `addr-${Date.now()}`
    };
    
    // If first address, set as default
    if (user.addresses.length === 0) {
      newAddress.isDefault = true;
    }
    
    const updatedUser = {
      ...user,
      addresses: [...user.addresses, newAddress],
      updatedAt: new Date()
    };
    
    setUser(updatedUser);
    localStorage.setItem('bluehat_user', JSON.stringify(updatedUser));
  }, [user]);

  const updateAddress = useCallback(async (addressId: string, data: Partial<User['addresses'][0]>) => {
    if (!user) return;
    
    const updatedAddresses = user.addresses.map(addr =>
      addr.id === addressId ? { ...addr, ...data } : addr
    );
    
    const updatedUser = {
      ...user,
      addresses: updatedAddresses,
      updatedAt: new Date()
    };
    
    setUser(updatedUser);
    localStorage.setItem('bluehat_user', JSON.stringify(updatedUser));
  }, [user]);

  const deleteAddress = useCallback(async (addressId: string) => {
    if (!user) return;
    
    const updatedAddresses = user.addresses.filter(addr => addr.id !== addressId);
    
    // If deleted address was default, set first remaining as default
    const deletedWasDefault = user.addresses.find(addr => addr.id === addressId)?.isDefault;
    if (deletedWasDefault && updatedAddresses.length > 0) {
      updatedAddresses[0].isDefault = true;
    }
    
    const updatedUser = {
      ...user,
      addresses: updatedAddresses,
      updatedAt: new Date()
    };
    
    setUser(updatedUser);
    localStorage.setItem('bluehat_user', JSON.stringify(updatedUser));
  }, [user]);

  const setDefaultAddress = useCallback(async (addressId: string) => {
    if (!user) return;
    
    const updatedAddresses = user.addresses.map(addr => ({
      ...addr,
      isDefault: addr.id === addressId
    }));
    
    const updatedUser = {
      ...user,
      addresses: updatedAddresses,
      updatedAt: new Date()
    };
    
    setUser(updatedUser);
    localStorage.setItem('bluehat_user', JSON.stringify(updatedUser));
  }, [user]);

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    isAdmin: user?.role === 'admin',
    login,
    loginWithGoogle,
    loginWithFacebook,
    register,
    logout,
    updateProfile,
    addAddress,
    updateAddress,
    deleteAddress,
    setDefaultAddress
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
