// ============================================
// BLUEHAT STORE - TESTIMONIALS SECTION
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Ahmad Rizky',
    role: 'Content Creator',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    content: 'Netflix berfungsi dengan baik! Sudah 2 bulan tidak ada masalah. Garansi juga responsif dan cepat. Highly recommended!',
    rotation: -2
  },
  {
    id: 2,
    name: 'Sarah Wijaya',
    role: 'Graphic Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    content: 'Beli Canva Pro disini, prosesnya cepat banget. Langsung dikirim ke email dalam hitungan menit. Bakal langganan terus!',
    rotation: 1
  },
  {
    id: 3,
    name: 'Budi Santoso',
    role: 'Gamer',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    rating: 4,
    content: 'Steam Wallet murah dan trusted. Sudah beli berkali-kali, never disappointed. Customer service juga ramah.',
    rotation: -1
  },
  {
    id: 4,
    name: 'Diana Putri',
    role: 'Student',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    content: 'ChatGPT Plus disini harganya paling murah! Prosesnya juga instant. Sangat membantu untuk tugas kuliah.',
    rotation: 2
  },
  {
    id: 5,
    name: 'Rudi Hartono',
    role: 'Entrepreneur',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    content: 'Pelayanan terbaik! Ada kendala langsung di respon. Produk digital lengkap dan harga bersaing.',
    rotation: -1
  },
  {
    id: 6,
    name: 'Maya Anggraini',
    role: 'Marketing Manager',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    content: 'Spotify Premium works perfectly! Langganan keluarga jadi lebih hemat. Terima kasih Bluehat Store!',
    rotation: 1
  }
];

export function TestimonialsSection() {
  return (
    <section className="testimonials-section">
      <div className="section-container">
        {/* Section Header */}
        <motion.div
          className="section-header center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            What Our <span className="title-accent">Customers</span> Say
          </h2>
          <p className="section-subtitle">
            Trusted by thousands of happy customers worldwide
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="testimonials-grid">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              className="testimonial-card"
              style={{ transform: `rotate(${testimonial.rotation}deg)` }}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1,
                ease: [0.16, 1, 0.3, 1]
              }}
              viewport={{ once: true }}
              whileHover={{ 
                scale: 1.03, 
                rotate: 0,
                zIndex: 10,
                transition: { duration: 0.2 }
              }}
            >
              {/* Quote Icon */}
              <div className="quote-icon">
                <Quote size={32} />
              </div>

              {/* Rating */}
              <div className="testimonial-rating">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={i < testimonial.rating ? 'filled' : ''}
                  />
                ))}
              </div>

              {/* Content */}
              <p className="testimonial-content">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="testimonial-author">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="author-avatar"
                  loading="lazy"
                />
                <div className="author-info">
                  <h4 className="author-name">{testimonial.name}</h4>
                  <span className="author-role">{testimonial.role}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
