// ============================================
// BLUEHAT STORE - FEATURED PRODUCTS SECTION
// ============================================

import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star, ShoppingCart, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { mockProducts } from '@/data/mockData';
import { useCart } from '@/contexts';

interface FeaturedProductsSectionProps {
  onProductClick: (productId: string) => void;
}

export function FeaturedProductsSection({ onProductClick }: FeaturedProductsSectionProps) {
  const { addToCart } = useCart();
  const scrollRef = useRef<HTMLDivElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });

  const featuredProducts = mockProducts.filter(p => p.isFeatured).slice(0, 8);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleAddToCart = (e: React.MouseEvent, product: typeof mockProducts[0]) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <section className="featured-products-section" ref={sectionRef}>
      <div className="section-container">
        {/* Section Header */}
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <div className="header-content">
            <h2 className="section-title">
              <span className="title-accent">Featured</span> Products
            </h2>
            <p className="section-subtitle">
              Handpicked premium items just for you
            </p>
          </div>
          
          <div className="header-actions">
            <motion.button
              className="nav-btn"
              onClick={() => scroll('left')}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronLeft size={20} />
            </motion.button>
            <motion.button
              className="nav-btn"
              onClick={() => scroll('right')}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronRight size={20} />
            </motion.button>
            <motion.button
              className="view-all-btn"
              onClick={() => onProductClick('')}
              whileHover={{ scale: 1.02 }}
            >
              View All
              <ArrowRight size={16} />
            </motion.button>
          </div>
        </motion.div>

        {/* Products Carousel */}
        <div className="products-carousel-container">
          <motion.div
            className="products-carousel"
            ref={scrollRef}
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                className="product-card"
                initial={{ opacity: 0, x: 50 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                onClick={() => onProductClick(product.id)}
              >
                {/* Image */}
                <div className="product-image">
                  <img 
                    src={product.thumbnail} 
                    alt={product.name}
                    loading="lazy"
                  />
                  
                  {/* Badges */}
                  <div className="product-badges">
                    {product.salePrice && (
                      <span className="badge sale">
                        {Math.round((1 - product.salePrice / product.price) * 100)}% OFF
                      </span>
                    )}
                    <span className={`badge type ${product.type}`}>
                      {product.type.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  {/* Quick Add */}
                  <motion.button
                    className="quick-add-btn"
                    onClick={(e) => handleAddToCart(e, product)}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ShoppingCart size={18} />
                  </motion.button>
                </div>

                {/* Content */}
                <div className="product-content">
                  <span className="product-category">{product.category}</span>
                  <h3 className="product-name">{product.name}</h3>
                  
                  {/* Rating */}
                  <div className="product-rating">
                    <div className="stars">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={i < Math.floor(product.rating) ? 'filled' : ''}
                        />
                      ))}
                    </div>
                    <span className="rating-count">({product.reviewCount})</span>
                  </div>

                  {/* Price */}
                  <div className="product-price">
                    {product.salePrice ? (
                      <>
                        <span className="sale-price">
                          {formatPrice(product.salePrice)}
                        </span>
                        <span className="original-price">
                          {formatPrice(product.price)}
                        </span>
                      </>
                    ) : (
                      <span className="price">{formatPrice(product.price)}</span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
