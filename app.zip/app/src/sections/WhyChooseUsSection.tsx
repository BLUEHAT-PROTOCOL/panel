// ============================================
// BLUEHAT STORE - WHY CHOOSE US SECTION
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Headphones, RotateCcw } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Instant Delivery',
    description: 'Get your products within minutes of purchase. No waiting, no delays.',
    color: '#38BDF8'
  },
  {
    icon: Shield,
    title: 'Secure Payments',
    description: 'Multiple payment methods with bank-grade encryption and security.',
    color: '#10B981'
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our dedicated team is always here to help you with any issues.',
    color: '#F59E0B'
  },
  {
    icon: RotateCcw,
    title: 'Money Back Guarantee',
    description: 'Not satisfied? Get a full refund within 7 days of purchase.',
    color: '#EF4444'
  }
];

export function WhyChooseUsSection() {
  return (
    <section className="why-choose-section">
      <div className="section-container">
        <div className="why-choose-grid">
          {/* Left Content */}
          <motion.div
            className="why-choose-content"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title">
              Why <span className="title-accent">Bluehat Store?</span>
            </h2>
            <p className="section-description">
              We're not just another marketplace. We're your trusted partner in the digital economy, 
              providing premium products with unmatched service quality.
            </p>
            <motion.button
              className="btn-outline"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Learn More About Us
            </motion.button>
          </motion.div>

          {/* Right Features Grid */}
          <div className="features-grid">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className="feature-card"
                initial={{ opacity: 0, y: 30, scale: 0.9 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ 
                  duration: 0.5, 
                  delay: index * 0.1,
                  ease: [0.16, 1, 0.3, 1]
                }}
                viewport={{ once: true }}
                whileHover={{ 
                  y: -5,
                  transition: { duration: 0.2 }
                }}
              >
                <motion.div 
                  className="feature-icon"
                  style={{ 
                    backgroundColor: `${feature.color}20`,
                    color: feature.color 
                  }}
                  whileHover={{ 
                    rotate: [0, -10, 10, 0],
                    scale: 1.1
                  }}
                  transition={{ duration: 0.5 }}
                >
                  <feature.icon size={28} />
                </motion.div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
