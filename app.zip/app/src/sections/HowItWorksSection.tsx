// ============================================
// BLUEHAT STORE - HOW IT WORKS SECTION
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { Search, MousePointer, CreditCard, Download } from 'lucide-react';

const steps = [
  {
    number: '01',
    icon: Search,
    title: 'Browse',
    description: 'Explore thousands of premium digital products across multiple categories.',
    color: '#2563EB'
  },
  {
    number: '02',
    icon: MousePointer,
    title: 'Select',
    description: 'Choose the perfect item for your needs with detailed descriptions and reviews.',
    color: '#38BDF8'
  },
  {
    number: '03',
    icon: CreditCard,
    title: 'Purchase',
    description: 'Pay securely with your preferred payment method. Multiple options available.',
    color: '#22D3EE'
  },
  {
    number: '04',
    icon: Download,
    title: 'Receive',
    description: 'Get instant delivery to your account. Start using your product immediately.',
    color: '#10B981'
  }
];

export function HowItWorksSection() {
  return (
    <section className="how-it-works-section">
      <div className="section-container">
        {/* Section Header */}
        <motion.div
          className="section-header center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            How It <span className="title-accent">Works</span>
          </h2>
          <p className="section-subtitle">
            Get started in four simple steps
          </p>
        </motion.div>

        {/* Steps */}
        <div className="steps-container">
          {/* Connection Line */}
          <svg className="steps-connector" viewBox="0 0 1000 200" preserveAspectRatio="none">
            <motion.path
              d="M 100 100 Q 250 50 400 100 T 700 100 T 1000 100"
              fill="none"
              stroke="url(#lineGradient)"
              strokeWidth="2"
              strokeDasharray="8 4"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              transition={{ duration: 2, ease: 'easeInOut' }}
              viewport={{ once: true }}
            />
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#2563EB" />
                <stop offset="50%" stopColor="#38BDF8" />
                <stop offset="100%" stopColor="#10B981" />
              </linearGradient>
            </defs>
          </svg>

          {/* Steps Grid */}
          <div className="steps-grid">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                className="step-card"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.15,
                  ease: [0.16, 1, 0.3, 1]
                }}
                viewport={{ once: true }}
              >
                <motion.div 
                  className="step-number"
                  style={{ color: step.color }}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ 
                    type: 'spring',
                    stiffness: 200,
                    delay: index * 0.15 + 0.3
                  }}
                  viewport={{ once: true }}
                >
                  {step.number}
                </motion.div>
                
                <motion.div 
                  className="step-icon"
                  style={{ 
                    backgroundColor: `${step.color}20`,
                    color: step.color 
                  }}
                  whileHover={{ 
                    rotate: 360,
                    scale: 1.1
                  }}
                  transition={{ duration: 0.6 }}
                >
                  <step.icon size={28} />
                </motion.div>
                
                <h3 className="step-title">{step.title}</h3>
                <p className="step-description">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
