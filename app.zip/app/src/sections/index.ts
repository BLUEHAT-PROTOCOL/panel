// ============================================
// BLUEHAT STORE - SECTIONS EXPORT
// ============================================

export { HeroSection } from './HeroSection';
export { CategoriesSection } from './CategoriesSection';
export { FeaturedProductsSection } from './FeaturedProductsSection';
export { WhyChooseUsSection } from './WhyChooseUsSection';
export { HowItWorksSection } from './HowItWorksSection';
export { TestimonialsSection } from './TestimonialsSection';
export { StatsSection } from './StatsSection';
export { CTASection } from './CTASection';
