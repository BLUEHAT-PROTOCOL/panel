// ============================================
// BLUEHAT STORE - CATEGORIES SECTION
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { 
  Laptop, 
  Gamepad2, 
  Play, 
  Briefcase, 
  Shield, 
  GraduationCap, 
  Palette,
  ArrowRight
} from 'lucide-react';
import { mockCategories } from '@/data/mockData';

interface CategoriesSectionProps {
  onCategoryClick: (categoryId: string) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Laptop,
  Gamepad2,
  Play,
  Briefcase,
  Shield,
  GraduationCap,
  Palette
};

export function CategoriesSection({ onCategoryClick }: CategoriesSectionProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30, rotateX: -15 },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        duration: 0.6,
        ease: [0.16, 1, 0.3, 1]
      }
    }
  };

  return (
    <section className="categories-section">
      <div className="section-container">
        {/* Section Header */}
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            <span className="title-accent">Browse</span> Categories
          </h2>
          <p className="section-subtitle">
            Find exactly what you need across our curated collections
          </p>
        </motion.div>

        {/* Categories Grid */}
        <motion.div
          className="categories-grid"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
        >
          {mockCategories.map((category, index) => {
            const Icon = iconMap[category.icon] || Laptop;
            
            return (
              <motion.div
                key={category.id}
                className="category-card"
                variants={itemVariants}
                whileHover={{ 
                  y: -10, 
                  scale: 1.02,
                  transition: { duration: 0.3 }
                }}
                onClick={() => onCategoryClick(category.id)}
              >
                <div className="card-background">
                  <img 
                    src={category.image} 
                    alt={category.name}
                    loading="lazy"
                  />
                  <div className="image-overlay" />
                </div>
                
                <div className="card-content">
                  <motion.div 
                    className="category-icon"
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon size={32} />
                  </motion.div>
                  
                  <h3 className="category-name">{category.name}</h3>
                  <p className="category-description">{category.description}</p>
                  
                  <div className="category-meta">
                    <span className="product-count">
                      {category.productCount.toLocaleString()} products
                    </span>
                    <motion.span 
                      className="explore-link"
                      whileHover={{ x: 5 }}
                    >
                      Explore <ArrowRight size={14} />
                    </motion.span>
                  </div>
                </div>

                <div className="card-glow" />
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
