// ============================================
// BLUEHAT STORE - TYPE DEFINITIONS
// ============================================

// User Types
export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: 'customer' | 'admin' | 'staff';
  phone?: string;
  addresses: Address[];
  createdAt: Date;
  updatedAt: Date;
  loyaltyPoints: number;
  membershipLevel?: 'bronze' | 'silver' | 'gold' | 'platinum';
  emailVerified: boolean;
}

export interface Address {
  id: string;
  label: string;
  recipientName: string;
  phone: string;
  street: string;
  city: string;
  province: string;
  postalCode: string;
  isDefault: boolean;
}

// Product Types
export type ProductType = 'physical' | 'digital' | 'subscription' | 'redeem_code' | 'license_key' | 'apps_premium';

export interface Product {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  price: number;
  salePrice?: number;
  costPrice?: number;
  type: ProductType;
  category: string;
  subcategory?: string;
  tags: string[];
  images: string[];
  thumbnail: string;
  stock: number;
  stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
  lowStockThreshold: number;
  sku: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  variants?: ProductVariant[];
  attributes?: Record<string, string>;
  rating: number;
  reviewCount: number;
  soldCount: number;
  viewCount: number;
  isFeatured: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  digitalDelivery?: DigitalDeliveryConfig;
}

export interface ProductVariant {
  id: string;
  name: string;
  options: string[];
  prices?: Record<string, number>;
  stock?: Record<string, number>;
}

export interface DigitalDeliveryConfig {
  autoDelivery: boolean;
  deliveryMethod: 'immediate' | 'manual' | 'scheduled';
  fileUrl?: string;
  downloadLimit?: number;
  expiryHours?: number;
  stockAccounts?: PremiumAccount[];
  stockCodes?: string[];
  licensePrefix?: string;
}

export interface PremiumAccount {
  id: string;
  email: string;
  password: string;
  profile?: string;
  duration: number;
  isUsed: boolean;
}

// Category Types
export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  icon: string;
  parentId?: string;
  children?: Category[];
  productCount: number;
  isActive: boolean;
  order: number;
}

// Cart Types
export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  variant?: string;
  price: number;
  addedAt: Date;
}

export interface Cart {
  items: CartItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  itemCount: number;
  couponCode?: string;
}

// Order Types
export type OrderStatus = 
  | 'pending' 
  | 'awaiting_payment' 
  | 'awaiting_confirmation' 
  | 'confirmed' 
  | 'processing' 
  | 'shipped' 
  | 'delivered' 
  | 'completed' 
  | 'cancelled' 
  | 'refunded';

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  user: User;
  items: OrderItem[];
  status: OrderStatus;
  statusHistory: StatusHistoryItem[];
  shippingAddress: Address;
  billingAddress: Address;
  subtotal: number;
  shippingCost: number;
  tax: number;
  discount: number;
  total: number;
  couponCode?: string;
  notes?: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  shippingMethod?: ShippingMethod;
  trackingNumber?: string;
  deliveredAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  expiredAt?: Date;
}

export interface OrderItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  price: number;
  variant?: string;
  deliveredData?: DeliveredData;
}

export interface DeliveredData {
  type: 'account' | 'code' | 'file' | 'license' | 'membership';
  data: any;
  deliveredAt: Date;
}

export interface StatusHistoryItem {
  status: OrderStatus;
  note?: string;
  createdAt: Date;
  createdBy: string;
}

// Payment Types
export type PaymentMethod = 
  | 'qris' 
  | 'dana' 
  | 'gopay' 
  | 'ovo' 
  | 'linkaja' 
  | 'bca' 
  | 'mandiri' 
  | 'bni' 
  | 'bri' 
  | 'credit_card' 
  | 'paypal';

export type PaymentStatus = 
  | 'pending' 
  | 'awaiting_confirmation' 
  | 'confirmed' 
  | 'rejected' 
  | 'refunded' 
  | 'expired';

export interface Payment {
  id: string;
  orderId: string;
  order: Order;
  method: PaymentMethod;
  amount: number;
  fee: number;
  total: number;
  status: PaymentStatus;
  proofImage?: string;
  proofData?: PaymentProofData;
  confirmedAt?: Date;
  confirmedBy?: string;
  rejectionReason?: string;
  expiryDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentProofData {
  senderName: string;
  senderAccount?: string;
  transferDate: Date;
  transferAmount: number;
  notes?: string;
}

export interface PaymentMethodConfig {
  id: PaymentMethod;
  name: string;
  icon: string;
  category: 'ewallet' | 'bank' | 'qris' | 'card' | 'international';
  instructions: string[];
  accountNumber?: string;
  accountName?: string;
  qrImage?: string;
  isActive: boolean;
  fee: number;
  feeType: 'fixed' | 'percentage';
  minAmount: number;
  maxAmount?: number;
  processingTime: string;
}

// Shipping Types
export interface ShippingMethod {
  id: string;
  name: string;
  provider: 'jne' | 'jnt' | 'sicepat' | 'gosend' | 'grabexpress' | 'anteraja';
  service: string;
  estimatedDays: string;
  cost: number;
  isActive: boolean;
}

// Review Types
export interface Review {
  id: string;
  productId: string;
  product: Product;
  userId: string;
  user: User;
  orderId: string;
  rating: number;
  title: string;
  content: string;
  images?: string[];
  isVerified: boolean;
  helpfulCount: number;
  createdAt: Date;
  updatedAt: Date;
}

// Coupon Types
export interface Coupon {
  id: string;
  code: string;
  description: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrderAmount?: number;
  maxDiscount?: number;
  usageLimit?: number;
  usageCount: number;
  userLimit?: number;
  startDate: Date;
  endDate: Date;
  applicableCategories?: string[];
  applicableProducts?: string[];
  isActive: boolean;
}

// Notification Types
export type NotificationType = 
  | 'order_created' 
  | 'order_confirmed' 
  | 'order_shipped' 
  | 'order_delivered' 
  | 'payment_received' 
  | 'payment_confirmed' 
  | 'payment_rejected' 
  | 'product_restocked' 
  | 'price_drop' 
  | 'promotion' 
  | 'system';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: any;
  isRead: boolean;
  createdAt: Date;
}

// Wishlist Types
export interface WishlistItem {
  id: string;
  userId: string;
  productId: string;
  product: Product;
  createdAt: Date;
}

// Chat Types
export interface Chat {
  id: string;
  userId: string;
  user: User;
  adminId?: string;
  subject: string;
  status: 'open' | 'closed';
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderType: 'customer' | 'admin' | 'system';
  content: string;
  attachments?: string[];
  isRead: boolean;
  createdAt: Date;
}

// Analytics Types
export interface AnalyticsEvent {
  id: string;
  type: string;
  userId?: string;
  sessionId: string;
  data: any;
  createdAt: Date;
}

// Webhook Types
export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  isActive: boolean;
  secret?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Settings Types
export interface StoreSettings {
  storeName: string;
  storeLogo: string;
  storeDescription: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  currency: string;
  timezone: string;
  taxRate: number;
  shippingFee: number;
  freeShippingThreshold?: number;
  orderExpiryHours: number;
  autoCancelEnabled: boolean;
  maintenanceMode: boolean;
}

// Admin Types
export interface AdminDashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  totalProducts: number;
  pendingOrders: number;
  pendingPayments: number;
  todayOrders: number;
  todayRevenue: number;
  lowStockProducts: number;
}

export interface SalesChartData {
  labels: string[];
  orders: number[];
  revenue: number[];
}

// Filter Types
export interface ProductFilter {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  rating?: number;
  inStock?: boolean;
  onSale?: boolean;
  sortBy?: 'price_asc' | 'price_desc' | 'newest' | 'popular' | 'rating';
  search?: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}
