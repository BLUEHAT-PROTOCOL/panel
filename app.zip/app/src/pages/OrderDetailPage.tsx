// ============================================
// BLUEHAT STORE - ORDER DETAIL PAGE
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Package, 
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  Download,
  Copy,
  Check
} from 'lucide-react';
import { useOrder } from '@/contexts';
import type { OrderStatus } from '@/types';

interface OrderDetailPageProps {
  orderId: string;
  onBack: () => void;
}

const statusConfig: Record<OrderStatus, { label: string; icon: React.ElementType; color: string; description: string }> = {
  pending: { 
    label: 'Pending', 
    icon: Clock, 
    color: '#F59E0B',
    description: 'Your order is pending payment'
  },
  awaiting_payment: { 
    label: 'Awaiting Payment', 
    icon: Clock, 
    color: '#F59E0B',
    description: 'Please complete your payment'
  },
  awaiting_confirmation: { 
    label: 'Awaiting Confirmation', 
    icon: Clock, 
    color: '#3B82F6',
    description: 'We are verifying your payment'
  },
  confirmed: { 
    label: 'Confirmed', 
    icon: CheckCircle, 
    color: '#10B981',
    description: 'Your order has been confirmed'
  },
  processing: { 
    label: 'Processing', 
    icon: Package, 
    color: '#8B5CF6',
    description: 'Your order is being processed'
  },
  shipped: { 
    label: 'Shipped', 
    icon: Truck, 
    color: '#3B82F6',
    description: 'Your order has been shipped'
  },
  delivered: { 
    label: 'Delivered', 
    icon: CheckCircle, 
    color: '#10B981',
    description: 'Your order has been delivered'
  },
  completed: { 
    label: 'Completed', 
    icon: CheckCircle, 
    color: '#10B981',
    description: 'Your order is complete'
  },
  cancelled: { 
    label: 'Cancelled', 
    icon: XCircle, 
    color: '#EF4444',
    description: 'Your order has been cancelled'
  },
  refunded: { 
    label: 'Refunded', 
    icon: XCircle, 
    color: '#6B7280',
    description: 'Your order has been refunded'
  }
};

export function OrderDetailPage({ orderId, onBack }: OrderDetailPageProps) {
  const { getOrderById } = useOrder();
  const order = getOrderById(orderId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const copyOrderNumber = () => {
    navigator.clipboard.writeText(order?.orderNumber || '');
  };

  if (!order) {
    return (
      <div className="order-detail-page">
        <div className="not-found">
          <Package size={64} />
          <h2>Order Not Found</h2>
          <button className="btn-primary" onClick={onBack}>
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  const status = statusConfig[order.status];
  const StatusIcon = status?.icon || Package;

  return (
    <div className="order-detail-page">
      {/* Header */}
      <div className="page-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back to Orders
        </motion.button>
        <div className="order-title">
          <h1>Order Details</h1>
          <div className="order-number-copy">
            <span>{order.orderNumber}</span>
            <motion.button
              onClick={copyOrderNumber}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Copy size={14} />
            </motion.button>
          </div>
        </div>
      </div>

      <div className="order-detail-layout">
        {/* Left Column */}
        <div className="order-main">
          {/* Status Card */}
          <motion.div
            className="status-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div 
              className="status-icon"
              style={{ backgroundColor: `${status?.color}20`, color: status?.color }}
            >
              <StatusIcon size={32} />
            </div>
            <div className="status-info">
              <h3 style={{ color: status?.color }}>{status?.label}</h3>
              <p>{status?.description}</p>
            </div>
          </motion.div>

          {/* Items */}
          <motion.div
            className="items-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <h3>Order Items</h3>
            <div className="items-list">
              {order.items.map((item) => (
                <div key={item.id} className="item-row">
                  <img 
                    src={item.product.thumbnail} 
                    alt={item.product.name}
                    loading="lazy"
                  />
                  <div className="item-details">
                    <h4>{item.product.name}</h4>
                    <p className="item-category">{item.product.category}</p>
                    <p className="item-price">
                      {formatPrice(item.price)} x {item.quantity}
                    </p>
                  </div>
                  <div className="item-total">
                    {formatPrice(item.price * item.quantity)}
                  </div>

                  {/* Delivered Data for Digital Products */}
                  {item.deliveredData && (
                    <div className="delivered-data">
                      <div className="data-header">
                        <CheckCircle size={14} />
                        <span>Delivered</span>
                      </div>
                      {item.deliveredData.type === 'account' && (
                        <div className="account-data">
                          <p><strong>Email:</strong> {item.deliveredData.data.email}</p>
                          <p><strong>Password:</strong> {item.deliveredData.data.password}</p>
                        </div>
                      )}
                      {item.deliveredData.type === 'code' && (
                        <div className="code-data">
                          <p><strong>Code:</strong> {item.deliveredData.data}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Timeline */}
          <motion.div
            className="timeline-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h3>Order Timeline</h3>
            <div className="timeline">
              {order.statusHistory.map((history, index) => (
                <div key={index} className="timeline-item">
                  <div className="timeline-dot" />
                  <div className="timeline-content">
                    <p className="timeline-status">
                      {statusConfig[history.status]?.label || history.status}
                    </p>
                    <p className="timeline-note">{history.note}</p>
                    <p className="timeline-date">{formatDate(history.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right Column - Summary */}
        <motion.div
          className="order-summary-card"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3>Order Summary</h3>
          
          <div className="summary-rows">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatPrice(order.subtotal)}</span>
            </div>
            {order.discount > 0 && (
              <div className="summary-row discount">
                <span>Discount</span>
                <span>-{formatPrice(order.discount)}</span>
              </div>
            )}
            <div className="summary-row">
              <span>Shipping</span>
              <span className="free">Free</span>
            </div>
            <div className="summary-row">
              <span>Tax</span>
              <span>{formatPrice(order.tax)}</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>{formatPrice(order.total)}</span>
            </div>
          </div>

          <div className="summary-divider" />

          {/* Payment Info */}
          <div className="payment-info">
            <h4>Payment Information</h4>
            <div className="info-row">
              <span>Method</span>
              <span className="capitalize">{order.paymentMethod}</span>
            </div>
            <div className="info-row">
              <span>Status</span>
              <span 
                className="payment-status"
                style={{ color: statusConfig[order.paymentStatus]?.color }}
              >
                {statusConfig[order.paymentStatus]?.label || order.paymentStatus}
              </span>
            </div>
          </div>

          {/* Shipping Info */}
          <div className="shipping-info">
            <h4>Shipping Address</h4>
            <p className="recipient">{order.shippingAddress.recipientName}</p>
            <p>{order.shippingAddress.phone}</p>
            <p>{order.shippingAddress.street}</p>
            <p>{order.shippingAddress.city}, {order.shippingAddress.province} {order.shippingAddress.postalCode}</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
