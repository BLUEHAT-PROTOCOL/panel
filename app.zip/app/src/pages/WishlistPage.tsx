// ============================================
// BLUEHAT STORE - WISHLIST PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Heart, 
  ShoppingCart, 
  Trash2,
  X
} from 'lucide-react';
import { mockProducts } from '@/data/mockData';
import { useCart } from '@/contexts';

interface WishlistPageProps {
  onBack: () => void;
  onProductClick: (productId: string) => void;
}

export function WishlistPage({ onBack, onProductClick }: WishlistPageProps) {
  const { addToCart } = useCart();
  const [wishlistItems, setWishlistItems] = useState<string[]>(['prod-1', 'prod-3', 'prod-5']);

  const products = mockProducts.filter(p => wishlistItems.includes(p.id));

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const removeFromWishlist = (productId: string) => {
    setWishlistItems(prev => prev.filter(id => id !== productId));
  };

  const handleAddToCart = (product: typeof mockProducts[0]) => {
    addToCart(product, 1);
  };

  const clearWishlist = () => {
    setWishlistItems([]);
  };

  return (
    <div className="wishlist-page">
      {/* Header */}
      <div className="page-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>
        <h1>My Wishlist</h1>
        {products.length > 0 && (
          <motion.button
            className="clear-btn"
            onClick={clearWishlist}
            whileHover={{ scale: 1.05 }}
          >
            <Trash2 size={16} />
            Clear All
          </motion.button>
        )}
      </div>

      {/* Content */}
      {products.length === 0 ? (
        <motion.div
          className="empty-state"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <Heart size={80} className="empty-icon" />
          <h2>Your wishlist is empty</h2>
          <p>Save products you love for later!</p>
          <motion.button
            className="btn-primary"
            onClick={onBack}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Continue Shopping
          </motion.button>
        </motion.div>
      ) : (
        <div className="wishlist-grid">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              className="wishlist-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div 
                className="card-image"
                onClick={() => onProductClick(product.id)}
              >
                <img 
                  src={product.thumbnail} 
                  alt={product.name}
                  loading="lazy"
                />
                <motion.button
                  className="remove-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeFromWishlist(product.id);
                  }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X size={16} />
                </motion.button>
              </div>

              <div className="card-content">
                <span className="product-category">{product.category}</span>
                <h3 onClick={() => onProductClick(product.id)}>{product.name}</h3>
                
                <div className="product-price">
                  {product.salePrice ? (
                    <>
                      <span className="sale-price">
                        {formatPrice(product.salePrice)}
                      </span>
                      <span className="original-price">
                        {formatPrice(product.price)}
                      </span>
                    </>
                  ) : (
                    <span className="price">{formatPrice(product.price)}</span>
                  )}
                </div>

                <motion.button
                  className="btn-add-cart"
                  onClick={() => handleAddToCart(product)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <ShoppingCart size={16} />
                  Add to Cart
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
