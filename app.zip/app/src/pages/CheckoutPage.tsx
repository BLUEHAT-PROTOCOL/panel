// ============================================
// BLUEHAT STORE - CHECKOUT PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  MapPin, 
  CreditCard, 
  ChevronRight,
  Check,
  AlertCircle
} from 'lucide-react';
import { useCart, useAuth, useOrder } from '@/contexts';
import { paymentMethods } from '@/data/mockData';

interface CheckoutPageProps {
  onBack: () => void;
  onOrderComplete: (orderId: string) => void;
}

export function CheckoutPage({ onBack, onOrderComplete }: CheckoutPageProps) {
  const { cart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const { createOrder } = useOrder();
  
  const [step, setStep] = useState<'address' | 'payment'>('address');
  const [selectedAddress, setSelectedAddress] = useState(user?.addresses.find(a => a.isDefault)?.id || '');
  const [selectedPayment, setSelectedPayment] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handlePlaceOrder = async () => {
    if (!selectedPayment) {
      setError('Please select a payment method');
      return;
    }

    setIsProcessing(true);
    setError('');

    try {
      const address = user?.addresses.find(a => a.id === selectedAddress);
      if (!address) {
        setError('Please select a shipping address');
        setIsProcessing(false);
        return;
      }

      const order = await createOrder({
        userId: user?.id || 'guest',
        items: cart.items.map(item => ({
          product: item.product,
          quantity: item.quantity,
          variant: item.variant
        })),
        shippingAddress: address,
        billingAddress: address,
        paymentMethod: selectedPayment,
        couponCode: cart.couponCode
      });

      onOrderComplete(order.id);
    } catch (err) {
      setError('Failed to create order. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="checkout-page">
        <motion.div
          className="auth-required"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <AlertCircle size={64} />
          <h2>Please Login</h2>
          <p>You need to be logged in to complete your purchase.</p>
          <motion.button
            className="btn-primary"
            onClick={onBack}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Go Back
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      {/* Header */}
      <div className="checkout-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back to Cart
        </motion.button>
        <h1>Checkout</h1>
      </div>

      {/* Progress */}
      <div className="checkout-progress">
        <div className={`progress-step ${step === 'address' ? 'active' : 'completed'}`}>
          <div className="step-number">1</div>
          <span>Address</span>
        </div>
        <div className="progress-line" />
        <div className={`progress-step ${step === 'payment' ? 'active' : ''}`}>
          <div className="step-number">2</div>
          <span>Payment</span>
        </div>
      </div>

      <div className="checkout-layout">
        {/* Main Content */}
        <div className="checkout-main">
          {step === 'address' ? (
            <motion.div
              className="address-section"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2>Select Shipping Address</h2>
              
              {user?.addresses.length === 0 ? (
                <div className="no-address">
                  <p>No addresses found. Please add an address in your profile.</p>
                  <motion.button
                    className="btn-primary"
                    onClick={onBack}
                    whileHover={{ scale: 1.05 }}
                  >
                    Go to Profile
                  </motion.button>
                </div>
              ) : (
                <div className="address-list">
                  {user?.addresses.map((address) => (
                    <motion.div
                      key={address.id}
                      className={`address-card ${selectedAddress === address.id ? 'selected' : ''}`}
                      onClick={() => setSelectedAddress(address.id)}
                      whileHover={{ scale: 1.01 }}
                    >
                      <div className="address-radio">
                        {selectedAddress === address.id && <Check size={16} />}
                      </div>
                      <div className="address-content">
                        <div className="address-header">
                          <span className="address-label">{address.label}</span>
                          {address.isDefault && (
                            <span className="default-badge">Default</span>
                          )}
                        </div>
                        <p className="recipient">{address.recipientName}</p>
                        <p className="phone">{address.phone}</p>
                        <p className="address-line">
                          {address.street}, {address.city}, {address.province} {address.postalCode}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}

              <motion.button
                className="btn-primary btn-large"
                onClick={() => setStep('payment')}
                disabled={!selectedAddress}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Continue to Payment
                <ChevronRight size={18} />
              </motion.button>
            </motion.div>
          ) : (
            <motion.div
              className="payment-section"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <button 
                className="back-to-address"
                onClick={() => setStep('address')}
              >
                <ArrowLeft size={16} />
                Change Address
              </button>

              <h2>Select Payment Method</h2>

              {error && (
                <div className="error-message">
                  <AlertCircle size={16} />
                  {error}
                </div>
              )}

              <div className="payment-methods">
                {/* E-Wallets */}
                <div className="payment-category">
                  <h3>E-Wallets</h3>
                  <div className="payment-grid">
                    {paymentMethods
                      .filter(p => p.category === 'ewallet')
                      .map((method) => (
                        <motion.div
                          key={method.id}
                          className={`payment-option ${selectedPayment === method.id ? 'selected' : ''}`}
                          onClick={() => setSelectedPayment(method.id)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="payment-radio">
                            {selectedPayment === method.id && <Check size={14} />}
                          </div>
                          <span className="payment-name">{method.name}</span>
                        </motion.div>
                      ))}
                  </div>
                </div>

                {/* Bank Transfer */}
                <div className="payment-category">
                  <h3>Bank Transfer</h3>
                  <div className="payment-grid">
                    {paymentMethods
                      .filter(p => p.category === 'bank')
                      .map((method) => (
                        <motion.div
                          key={method.id}
                          className={`payment-option ${selectedPayment === method.id ? 'selected' : ''}`}
                          onClick={() => setSelectedPayment(method.id)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="payment-radio">
                            {selectedPayment === method.id && <Check size={14} />}
                          </div>
                          <span className="payment-name">{method.name}</span>
                        </motion.div>
                      ))}
                  </div>
                </div>

                {/* QRIS */}
                <div className="payment-category">
                  <h3>QRIS</h3>
                  <div className="payment-grid">
                    {paymentMethods
                      .filter(p => p.category === 'qris')
                      .map((method) => (
                        <motion.div
                          key={method.id}
                          className={`payment-option ${selectedPayment === method.id ? 'selected' : ''}`}
                          onClick={() => setSelectedPayment(method.id)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="payment-radio">
                            {selectedPayment === method.id && <Check size={14} />}
                          </div>
                          <span className="payment-name">{method.name}</span>
                        </motion.div>
                      ))}
                  </div>
                </div>
              </div>

              <motion.button
                className="btn-primary btn-large btn-full"
                onClick={handlePlaceOrder}
                disabled={isProcessing || !selectedPayment}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {isProcessing ? 'Processing...' : 'Place Order'}
              </motion.button>
            </motion.div>
          )}
        </div>

        {/* Order Summary */}
        <motion.div
          className="checkout-summary"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2>Order Summary</h2>
          
          <div className="summary-items">
            {cart.items.map((item) => (
              <div key={item.id} className="summary-item">
                <div className="item-info">
                  <img src={item.product.thumbnail} alt={item.product.name} />
                  <div>
                    <p className="item-name">{item.product.name}</p>
                    <p className="item-qty">Qty: {item.quantity}</p>
                  </div>
                </div>
                <span className="item-price">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          <div className="summary-divider" />

          <div className="summary-totals">
            <div className="total-row">
              <span>Subtotal</span>
              <span>{formatPrice(cart.subtotal)}</span>
            </div>
            {cart.discount > 0 && (
              <div className="total-row discount">
                <span>Discount</span>
                <span>-{formatPrice(cart.discount)}</span>
              </div>
            )}
            <div className="total-row">
              <span>Shipping</span>
              <span className="free">Free</span>
            </div>
            <div className="total-row">
              <span>Tax</span>
              <span>{formatPrice(cart.tax)}</span>
            </div>
            <div className="total-row grand-total">
              <span>Total</span>
              <span>{formatPrice(cart.total)}</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
