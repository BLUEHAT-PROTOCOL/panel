// ============================================
// BLUEHAT STORE - PRODUCT DETAIL PAGE
// ============================================

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Star, 
  ShoppingCart, 
  Heart, 
  Share2, 
  Check,
  Shield,
  Zap,
  Clock,
  Minus,
  Plus
} from 'lucide-react';
import { mockProducts, mockReviews } from '@/data/mockData';
import { useCart } from '@/contexts';

interface ProductDetailPageProps {
  productId: string;
  onBack: () => void;
  onAddToCart: () => void;
}

export function ProductDetailPage({ productId, onBack, onAddToCart }: ProductDetailPageProps) {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [activeTab, setActiveTab] = useState<'description' | 'reviews'>('description');

  // Find product (in real app, fetch from API)
  const product = mockProducts.find(p => p.id === productId) || mockProducts[0];
  const productReviews = mockReviews.filter(r => r.productId === productId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onAddToCart();
  };

  const images = product.images.length > 0 ? product.images : [product.thumbnail];

  return (
    <div className="product-detail-page">
      {/* Back Button */}
      <motion.button
        className="back-button"
        onClick={onBack}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        whileHover={{ x: -5 }}
      >
        <ArrowLeft size={20} />
        Back to Products
      </motion.button>

      <div className="product-detail-container">
        {/* Image Gallery */}
        <motion.div 
          className="product-gallery"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="main-image">
            <motion.img
              key={activeImage}
              src={images[activeImage]}
              alt={product.name}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />
            {product.salePrice && (
              <span className="sale-badge">
                {Math.round((1 - product.salePrice / product.price) * 100)}% OFF
              </span>
            )}
          </div>
          
          {images.length > 1 && (
            <div className="thumbnail-list">
              {images.map((img, index) => (
                <motion.button
                  key={index}
                  className={`thumbnail ${activeImage === index ? 'active' : ''}`}
                  onClick={() => setActiveImage(index)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <img src={img} alt={`${product.name} ${index + 1}`} />
                </motion.button>
              ))}
            </div>
          )}
        </motion.div>

        {/* Product Info */}
        <motion.div 
          className="product-info"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          {/* Category & Rating */}
          <div className="product-meta">
            <span className="product-category">{product.category}</span>
            <div className="product-rating">
              <div className="stars">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < Math.floor(product.rating) ? 'filled' : ''}
                  />
                ))}
              </div>
              <span>{product.rating}</span>
              <span className="review-count">({product.reviewCount} reviews)</span>
            </div>
          </div>

          {/* Name */}
          <h1 className="product-name">{product.name}</h1>

          {/* Short Description */}
          <p className="product-short-desc">{product.shortDescription}</p>

          {/* Price */}
          <div className="product-price">
            {product.salePrice ? (
              <>
                <span className="current-price">
                  {formatPrice(product.salePrice)}
                </span>
                <span className="original-price">
                  {formatPrice(product.price)}
                </span>
                <span className="save-badge">
                  Save {formatPrice(product.price - product.salePrice)}
                </span>
              </>
            ) : (
              <span className="current-price">
                {formatPrice(product.price)}
              </span>
            )}
          </div>

          {/* Features */}
          <div className="product-features">
            <div className="feature">
              <Zap size={18} />
              <span>Instant Delivery</span>
            </div>
            <div className="feature">
              <Shield size={18} />
              <span>30 Days Warranty</span>
            </div>
            <div className="feature">
              <Clock size={18} />
              <span>24/7 Support</span>
            </div>
          </div>

          {/* Quantity */}
          <div className="quantity-selector">
            <span>Quantity:</span>
            <div className="quantity-control">
              <motion.button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Minus size={14} />
              </motion.button>
              <span>{quantity}</span>
              <motion.button
                onClick={() => setQuantity(quantity + 1)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Plus size={14} />
              </motion.button>
            </div>
          </div>

          {/* Actions */}
          <div className="product-actions">
            <motion.button
              className="btn-primary btn-large add-to-cart"
              onClick={handleAddToCart}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <ShoppingCart size={20} />
              Add to Cart
            </motion.button>
            
            <motion.button
              className={`btn-icon wishlist ${isWishlisted ? 'active' : ''}`}
              onClick={() => setIsWishlisted(!isWishlisted)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart size={20} fill={isWishlisted ? 'currentColor' : 'none'} />
            </motion.button>
            
            <motion.button
              className="btn-icon share"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Share2 size={20} />
            </motion.button>
          </div>

          {/* Stock Status */}
          <div className="stock-status">
            <Check size={16} className="in-stock" />
            <span>In Stock ({product.stock} available)</span>
          </div>

          {/* Tabs */}
          <div className="product-tabs">
            <div className="tab-buttons">
              <button
                className={activeTab === 'description' ? 'active' : ''}
                onClick={() => setActiveTab('description')}
              >
                Description
              </button>
              <button
                className={activeTab === 'reviews' ? 'active' : ''}
                onClick={() => setActiveTab('reviews')}
              >
                Reviews ({productReviews.length})
              </button>
            </div>

            <AnimatePresence mode="wait">
              {activeTab === 'description' ? (
                <motion.div
                  key="description"
                  className="tab-content"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <p>{product.description}</p>
                  
                  <h4>Product Details:</h4>
                  <ul className="details-list">
                    <li>Type: {product.type.replace('_', ' ').toUpperCase()}</li>
                    <li>SKU: {product.sku}</li>
                    <li>Category: {product.category}</li>
                    {product.digitalDelivery?.duration && (
                      <li>Duration: {product.digitalDelivery.duration} days</li>
                    )}
                    {product.digitalDelivery?.warrantyDays && (
                      <li>Warranty: {product.digitalDelivery.warrantyDays} days</li>
                    )}
                  </ul>
                </motion.div>
              ) : (
                <motion.div
                  key="reviews"
                  className="tab-content"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  {productReviews.length > 0 ? (
                    <div className="reviews-list">
                      {productReviews.map((review) => (
                        <div key={review.id} className="review-item">
                          <div className="review-header">
                            <img 
                              src={review.user.photoURL} 
                              alt={review.user.displayName}
                              className="reviewer-avatar"
                            />
                            <div className="reviewer-info">
                              <h4>{review.user.displayName}</h4>
                              <div className="review-rating">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    size={12}
                                    className={i < review.rating ? 'filled' : ''}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>
                          <h5>{review.title}</h5>
                          <p>{review.content}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="no-reviews">No reviews yet. Be the first to review!</p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
