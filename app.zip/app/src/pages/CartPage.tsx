// ============================================
// BLUEHAT STORE - CART PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Minus, 
  Plus, 
  Trash2, 
  ShoppingBag,
  Tag,
  ArrowRight
} from 'lucide-react';
import { useCart } from '@/contexts';

interface CartPageProps {
  onCheckout: () => void;
  onContinueShopping: () => void;
}

export function CartPage({ onCheckout, onContinueShopping }: CartPageProps) {
  const { cart, removeFromCart, updateQuantity, applyCoupon, removeCoupon } = useCart();
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState('');
  const [isApplying, setIsApplying] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    
    setIsApplying(true);
    setCouponError('');
    
    const success = await applyCoupon(couponCode);
    
    if (!success) {
      setCouponError('Invalid or expired coupon code');
    }
    
    setIsApplying(false);
  };

  if (cart.items.length === 0) {
    return (
      <div className="cart-page empty">
        <motion.div
          className="empty-state"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <ShoppingBag size={80} />
          <h2>Your cart is empty</h2>
          <p>Add some products to get started!</p>
          <motion.button
            className="btn-primary"
            onClick={onContinueShopping}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Continue Shopping
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="cart-header">
        <motion.button
          className="back-button"
          onClick={onContinueShopping}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Continue Shopping
        </motion.button>
        <h1>Shopping Cart ({cart.itemCount} items)</h1>
      </div>

      <div className="cart-layout">
        {/* Cart Items */}
        <motion.div
          className="cart-items-section"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {cart.items.map((item, index) => (
            <motion.div
              key={item.id}
              className="cart-item-card"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <img 
                src={item.product.thumbnail} 
                alt={item.product.name}
                className="item-image"
              />
              
              <div className="item-details">
                <h3>{item.product.name}</h3>
                <p className="item-category">{item.product.category}</p>
                <p className="item-price">{formatPrice(item.price)}</p>
              </div>

              <div className="item-quantity">
                <motion.button
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  disabled={item.quantity <= 1}
                >
                  <Minus size={14} />
                </motion.button>
                <span>{item.quantity}</span>
                <motion.button
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Plus size={14} />
                </motion.button>
              </div>

              <div className="item-total">
                <span>{formatPrice(item.price * item.quantity)}</span>
              </div>

              <motion.button
                className="remove-btn"
                onClick={() => removeFromCart(item.id)}
                whileHover={{ scale: 1.1, color: '#EF4444' }}
                whileTap={{ scale: 0.9 }}
              >
                <Trash2 size={18} />
              </motion.button>
            </motion.div>
          ))}
        </motion.div>

        {/* Order Summary */}
        <motion.div
          className="order-summary"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2>Order Summary</h2>

          {/* Coupon */}
          <div className="coupon-section">
            <div className="coupon-input">
              <Tag size={18} />
              <input
                type="text"
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                disabled={!!cart.couponCode}
              />
              {cart.couponCode ? (
                <button 
                  className="btn-remove-coupon"
                  onClick={removeCoupon}
                >
                  Remove
                </button>
              ) : (
                <button
                  className="btn-apply-coupon"
                  onClick={handleApplyCoupon}
                  disabled={isApplying || !couponCode.trim()}
                >
                  {isApplying ? '...' : 'Apply'}
                </button>
              )}
            </div>
            {couponError && (
              <span className="coupon-error">{couponError}</span>
            )}
            {cart.couponCode && (
              <span className="coupon-success">
                Coupon applied: {cart.couponCode}
              </span>
            )}
          </div>

          {/* Summary */}
          <div className="summary-details">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatPrice(cart.subtotal)}</span>
            </div>
            {cart.discount > 0 && (
              <div className="summary-row discount">
                <span>Discount</span>
                <span>-{formatPrice(cart.discount)}</span>
              </div>
            )}
            <div className="summary-row">
              <span>Tax</span>
              <span>{formatPrice(cart.tax)}</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>{formatPrice(cart.total)}</span>
            </div>
          </div>

          <motion.button
            className="btn-primary btn-large btn-full checkout-btn"
            onClick={onCheckout}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Proceed to Checkout
            <ArrowRight size={18} />
          </motion.button>

          <p className="secure-note">
            Secure checkout powered by Bluehat Store
          </p>
        </motion.div>
      </div>
    </div>
  );
}
