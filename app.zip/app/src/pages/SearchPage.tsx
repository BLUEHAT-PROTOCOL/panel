// ============================================
// BLUEHAT STORE - SEARCH PAGE
// ============================================

import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Search, 
  SlidersHorizontal,
  Star,
  ShoppingCart,
  X
} from 'lucide-react';
import { mockProducts, mockCategories } from '@/data/mockData';
import { useCart } from '@/contexts';

interface SearchPageProps {
  initialQuery?: string;
  onProductClick: (productId: string) => void;
  onBack: () => void;
}

export function SearchPage({ initialQuery = '', onProductClick, onBack }: SearchPageProps) {
  const { addToCart } = useCart();
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000000]);
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'newest' | 'popular'>('popular');
  const [showFilters, setShowFilters] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const filteredProducts = useMemo(() => {
    let products = [...mockProducts];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      products = products.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      const category = mockCategories.find(c => c.id === selectedCategory);
      if (category) {
        products = products.filter(p => p.category === category.name);
      }
    }

    // Price filter
    products = products.filter(p => {
      const price = p.salePrice || p.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });

    // Sort
    products.sort((a, b) => {
      switch (sortBy) {
        case 'price_asc':
          return (a.salePrice || a.price) - (b.salePrice || b.price);
        case 'price_desc':
          return (b.salePrice || b.price) - (a.salePrice || a.price);
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'popular':
        default:
          return b.soldCount - a.soldCount;
      }
    });

    return products;
  }, [searchQuery, selectedCategory, priceRange, sortBy]);

  const handleAddToCart = (e: React.MouseEvent, product: typeof mockProducts[0]) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <div className="search-page">
      {/* Header */}
      <div className="search-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>

        <div className="search-bar">
          <Search size={20} />
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
          />
          {searchQuery && (
            <button 
              className="clear-search"
              onClick={() => setSearchQuery('')}
            >
              <X size={16} />
            </button>
          )}
        </div>

        <motion.button
          className={`filter-toggle ${showFilters ? 'active' : ''}`}
          onClick={() => setShowFilters(!showFilters)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <SlidersHorizontal size={20} />
          Filters
        </motion.button>
      </div>

      <div className="search-layout">
        {/* Filters Sidebar */}
        <motion.aside
          className={`filters-sidebar ${showFilters ? 'open' : ''}`}
          initial={false}
          animate={{ x: showFilters ? 0 : '-100%' }}
        >
          <div className="filter-section">
            <h4>Categories</h4>
            <div className="filter-options">
              <label className="filter-option">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'all'}
                  onChange={() => setSelectedCategory('all')}
                />
                <span>All Categories</span>
              </label>
              {mockCategories.map(cat => (
                <label key={cat.id} className="filter-option">
                  <input
                    type="radio"
                    name="category"
                    checked={selectedCategory === cat.id}
                    onChange={() => setSelectedCategory(cat.id)}
                  />
                  <span>{cat.name}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="filter-section">
            <h4>Price Range</h4>
            <div className="price-inputs">
              <input
                type="number"
                placeholder="Min"
                value={priceRange[0]}
                onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
              />
              <span>-</span>
              <input
                type="number"
                placeholder="Max"
                value={priceRange[1]}
                onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000000])}
              />
            </div>
          </div>
        </motion.aside>

        {/* Results */}
        <div className="search-results">
          {/* Sort & Count */}
          <div className="results-header">
            <span className="results-count">
              {filteredProducts.length} products found
            </span>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="sort-select"
            >
              <option value="popular">Most Popular</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="newest">Newest First</option>
            </select>
          </div>

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="no-results">
              <Search size={64} />
              <h3>No products found</h3>
              <p>Try adjusting your search or filters</p>
            </div>
          ) : (
            <div className="products-grid">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  className="product-card"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => onProductClick(product.id)}
                  whileHover={{ y: -5 }}
                >
                  <div className="card-image">
                    <img 
                      src={product.thumbnail} 
                      alt={product.name}
                      loading="lazy"
                    />
                    {product.salePrice && (
                      <span className="sale-badge">
                        {Math.round((1 - product.salePrice / product.price) * 100)}% OFF
                      </span>
                    )}
                    <motion.button
                      className="quick-add"
                      onClick={(e) => handleAddToCart(e, product)}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <ShoppingCart size={16} />
                    </motion.button>
                  </div>
                  
                  <div className="card-content">
                    <span className="product-category">{product.category}</span>
                    <h3 className="product-name">{product.name}</h3>
                    
                    <div className="product-rating">
                      <div className="stars">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={12}
                            className={i < Math.floor(product.rating) ? 'filled' : ''}
                          />
                        ))}
                      </div>
                      <span>({product.reviewCount})</span>
                    </div>

                    <div className="product-price">
                      {product.salePrice ? (
                        <>
                          <span className="sale-price">
                            {formatPrice(product.salePrice)}
                          </span>
                          <span className="original-price">
                            {formatPrice(product.price)}
                          </span>
                        </>
                      ) : (
                        <span className="price">{formatPrice(product.price)}</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
