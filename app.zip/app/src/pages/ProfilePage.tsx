// ============================================
// BLUEHAT STORE - PROFILE PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Plus,
  Edit2,
  Trash2,
  Check,
  Star,
  Award
} from 'lucide-react';
import { useAuth } from '@/contexts';

interface ProfilePageProps {
  onBack: () => void;
}

export function ProfilePage({ onBack }: ProfilePageProps) {
  const { user, updateProfile, addAddress, updateAddress, deleteAddress, setDefaultAddress } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [editData, setEditData] = useState({
    displayName: user?.displayName || '',
    phone: user?.phone || ''
  });

  const [newAddress, setNewAddress] = useState({
    label: '',
    recipientName: '',
    phone: '',
    street: '',
    city: '',
    province: '',
    postalCode: ''
  });

  const handleSaveProfile = async () => {
    await updateProfile({
      displayName: editData.displayName,
      phone: editData.phone
    });
    setIsEditing(false);
  };

  const handleAddAddress = async () => {
    await addAddress(newAddress);
    setShowAddAddress(false);
    setNewAddress({
      label: '',
      recipientName: '',
      phone: '',
      street: '',
      city: '',
      province: '',
      postalCode: ''
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  if (!user) {
    return (
      <div className="profile-page">
        <div className="not-found">
          <User size={64} />
          <h2>Please login to view your profile</h2>
          <button className="btn-primary" onClick={onBack}>
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="profile-page">
      {/* Header */}
      <div className="page-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>
        <h1>My Profile</h1>
      </div>

      <div className="profile-layout">
        {/* Left Column - Profile Info */}
        <div className="profile-main">
          {/* Profile Card */}
          <motion.div
            className="profile-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="profile-header">
              <div className="profile-avatar">
                <img src={user.photoURL || '/default-avatar.png'} alt={user.displayName} />
                <div className={`membership-badge ${user.membershipLevel}`}>
                  <Star size={12} fill="currentColor" />
                </div>
              </div>
              <div className="profile-info">
                {isEditing ? (
                  <div className="edit-form">
                    <input
                      type="text"
                      value={editData.displayName}
                      onChange={(e) => setEditData({ ...editData, displayName: e.target.value })}
                      placeholder="Display Name"
                    />
                    <input
                      type="tel"
                      value={editData.phone}
                      onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                      placeholder="Phone Number"
                    />
                    <div className="edit-actions">
                      <button className="btn-save" onClick={handleSaveProfile}>
                        <Check size={16} />
                        Save
                      </button>
                      <button className="btn-cancel" onClick={() => setIsEditing(false)}>
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h2>{user.displayName}</h2>
                    <p className="membership-level">
                      <Award size={14} />
                      {user.membershipLevel?.toUpperCase()} Member
                    </p>
                    <div className="profile-meta">
                      <span><Mail size={14} /> {user.email}</span>
                      {user.phone && <span><Phone size={14} /> {user.phone}</span>}
                    </div>
                    <motion.button
                      className="btn-edit"
                      onClick={() => setIsEditing(true)}
                      whileHover={{ scale: 1.05 }}
                    >
                      <Edit2 size={14} />
                      Edit Profile
                    </motion.button>
                  </>
                )}
              </div>
            </div>

            {/* Loyalty Points */}
            <div className="loyalty-card">
              <div className="loyalty-info">
                <span className="loyalty-label">Loyalty Points</span>
                <span className="loyalty-value">{user.loyaltyPoints.toLocaleString()}</span>
              </div>
              <div className="loyalty-progress">
                <div 
                  className="progress-bar"
                  style={{ width: `${Math.min((user.loyaltyPoints / 5000) * 100, 100)}%` }}
                />
              </div>
              <p className="loyalty-text">
                {5000 - user.loyaltyPoints > 0 
                  ? `${(5000 - user.loyaltyPoints).toLocaleString()} points to Gold`
                  : 'You are a Gold Member!'}
              </p>
            </div>
          </motion.div>

          {/* Addresses */}
          <motion.div
            className="addresses-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="card-header">
              <h3><MapPin size={18} /> Saved Addresses</h3>
              <motion.button
                className="btn-add"
                onClick={() => setShowAddAddress(true)}
                whileHover={{ scale: 1.05 }}
              >
                <Plus size={16} />
                Add New
              </motion.button>
            </div>

            {showAddAddress && (
              <motion.div
                className="add-address-form"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
              >
                <input
                  type="text"
                  placeholder="Label (e.g., Home, Office)"
                  value={newAddress.label}
                  onChange={(e) => setNewAddress({ ...newAddress, label: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="Recipient Name"
                  value={newAddress.recipientName}
                  onChange={(e) => setNewAddress({ ...newAddress, recipientName: e.target.value })}
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={newAddress.phone}
                  onChange={(e) => setNewAddress({ ...newAddress, phone: e.target.value })}
                />
                <textarea
                  placeholder="Street Address"
                  value={newAddress.street}
                  onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                />
                <div className="form-row">
                  <input
                    type="text"
                    placeholder="City"
                    value={newAddress.city}
                    onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                  />
                  <input
                    type="text"
                    placeholder="Province"
                    value={newAddress.province}
                    onChange={(e) => setNewAddress({ ...newAddress, province: e.target.value })}
                  />
                </div>
                <input
                  type="text"
                  placeholder="Postal Code"
                  value={newAddress.postalCode}
                  onChange={(e) => setNewAddress({ ...newAddress, postalCode: e.target.value })}
                />
                <div className="form-actions">
                  <button className="btn-save" onClick={handleAddAddress}>
                    <Check size={16} />
                    Save Address
                  </button>
                  <button className="btn-cancel" onClick={() => setShowAddAddress(false)}>
                    Cancel
                  </button>
                </div>
              </motion.div>
            )}

            <div className="addresses-list">
              {user.addresses.length === 0 ? (
                <p className="no-addresses">No saved addresses</p>
              ) : (
                user.addresses.map((address) => (
                  <div key={address.id} className={`address-item ${address.isDefault ? 'default' : ''}`}>
                    <div className="address-content">
                      <div className="address-header">
                        <span className="label">{address.label}</span>
                        {address.isDefault && <span className="default-badge">Default</span>}
                      </div>
                      <p className="recipient">{address.recipientName}</p>
                      <p className="phone">{address.phone}</p>
                      <p className="address-text">
                        {address.street}, {address.city}, {address.province} {address.postalCode}
                      </p>
                    </div>
                    <div className="address-actions">
                      {!address.isDefault && (
                        <motion.button
                          onClick={() => setDefaultAddress(address.id)}
                          whileHover={{ scale: 1.1 }}
                          title="Set as default"
                        >
                          <Check size={16} />
                        </motion.button>
                      )}
                      <motion.button
                        onClick={() => deleteAddress(address.id)}
                        whileHover={{ scale: 1.1 }}
                        className="delete"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </motion.button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
