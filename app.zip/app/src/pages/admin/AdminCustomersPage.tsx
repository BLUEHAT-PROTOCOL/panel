// ============================================
// BLUEHAT STORE - ADMIN CUSTOMERS PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Users,
  Mail,
  ShoppingBag,
  Star,
  Eye,
  Filter
} from 'lucide-react';

// Mock customers data
const mockCustomers = [
  {
    id: 'user-1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '0812-3456-7890',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    membershipLevel: 'silver',
    loyaltyPoints: 1250,
    totalOrders: 15,
    totalSpent: 2500000,
    joinedAt: new Date('2024-01-15')
  },
  {
    id: 'user-2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    phone: '0813-4567-8901',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    membershipLevel: 'gold',
    loyaltyPoints: 3500,
    totalOrders: 32,
    totalSpent: 8500000,
    joinedAt: new Date('2023-12-01')
  },
  {
    id: 'user-3',
    name: 'Ahmad Rizky',
    email: 'ahmad@example.com',
    phone: '0814-5678-9012',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    membershipLevel: 'bronze',
    loyaltyPoints: 450,
    totalOrders: 5,
    totalSpent: 750000,
    joinedAt: new Date('2024-02-20')
  },
  {
    id: 'user-4',
    name: 'Sarah Wijaya',
    email: 'sarah@example.com',
    phone: '0815-6789-0123',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    membershipLevel: 'platinum',
    loyaltyPoints: 8200,
    totalOrders: 58,
    totalSpent: 15000000,
    joinedAt: new Date('2023-08-10')
  },
  {
    id: 'user-5',
    name: 'Budi Santoso',
    email: 'budi@example.com',
    phone: '0816-7890-1234',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    membershipLevel: 'silver',
    loyaltyPoints: 1800,
    totalOrders: 22,
    totalSpent: 4200000,
    joinedAt: new Date('2024-01-05')
  }
];

export function AdminCustomersPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [membershipFilter, setMembershipFilter] = useState<string>('all');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const filteredCustomers = mockCustomers.filter(customer => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.phone.includes(searchQuery);
    
    const matchesMembership = membershipFilter === 'all' || customer.membershipLevel === membershipFilter;
    
    return matchesSearch && matchesMembership;
  });

  const membershipColors: Record<string, string> = {
    bronze: '#CD7F32',
    silver: '#C0C0C0',
    gold: '#FFD700',
    platinum: '#E5E4E2'
  };

  return (
    <div className="admin-customers-page">
      {/* Header */}
      <div className="admin-header">
        <h1>Customers Management</h1>
        <p>View and manage your customers</p>
      </div>

      {/* Stats */}
      <div className="customers-stats">
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#2563EB20', color: '#2563EB' }}>
            <Users size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">{mockCustomers.length}</span>
            <span className="stat-label">Total Customers</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#FFD70020', color: '#FFD700' }}>
            <Star size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">
              {mockCustomers.filter(c => ['gold', 'platinum'].includes(c.membershipLevel)).length}
            </span>
            <span className="stat-label">VIP Members</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#10B98120', color: '#10B981' }}>
            <ShoppingBag size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">
              {mockCustomers.reduce((sum, c) => sum + c.totalOrders, 0)}
            </span>
            <span className="stat-label">Total Orders</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#8B5CF620', color: '#8B5CF6' }}>
            <Users size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">
              {mockCustomers.filter(c => new Date(c.joinedAt).getMonth() === new Date().getMonth()).length}
            </span>
            <span className="stat-label">New This Month</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search customers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="filter-group">
          <Filter size={16} />
          <select 
            value={membershipFilter}
            onChange={(e) => setMembershipFilter(e.target.value)}
          >
            <option value="all">All Memberships</option>
            <option value="bronze">Bronze</option>
            <option value="silver">Silver</option>
            <option value="gold">Gold</option>
            <option value="platinum">Platinum</option>
          </select>
        </div>
      </div>

      {/* Customers Table */}
      <div className="customers-table-container">
        <table className="customers-table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Contact</th>
              <th>Membership</th>
              <th>Points</th>
              <th>Orders</th>
              <th>Total Spent</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.length === 0 ? (
              <tr>
                <td colSpan={8} className="empty-cell">
                  <div className="empty-state">
                    <Users size={48} />
                    <p>No customers found</p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredCustomers.map((customer) => (
                <motion.tr
                  key={customer.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <td>
                    <div className="customer-info">
                      <img 
                        src={customer.avatar} 
                        alt={customer.name}
                        className="customer-avatar"
                      />
                      <span className="customer-name">{customer.name}</span>
                    </div>
                  </td>
                  <td>
                    <div className="contact-info">
                      <span><Mail size={12} /> {customer.email}</span>
                      <span>{customer.phone}</span>
                    </div>
                  </td>
                  <td>
                    <span 
                      className="membership-badge"
                      style={{ 
                        backgroundColor: `${membershipColors[customer.membershipLevel]}20`,
                        color: membershipColors[customer.membershipLevel]
                      }}
                    >
                      <Star size={12} fill="currentColor" />
                      {customer.membershipLevel.toUpperCase()}
                    </span>
                  </td>
                  <td>
                    <span className="points">{customer.loyaltyPoints.toLocaleString()}</span>
                  </td>
                  <td>
                    <span className="orders-count">{customer.totalOrders}</span>
                  </td>
                  <td>
                    <span className="total-spent">{formatPrice(customer.totalSpent)}</span>
                  </td>
                  <td>
                    <span className="joined-date">{formatDate(customer.joinedAt)}</span>
                  </td>
                  <td>
                    <motion.button
                      className="btn-view"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Eye size={16} />
                    </motion.button>
                  </td>
                </motion.tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
