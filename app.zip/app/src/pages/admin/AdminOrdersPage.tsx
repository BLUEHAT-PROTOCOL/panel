// ============================================
// BLUEHAT STORE - ADMIN ORDERS PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Eye,
  Filter,
  Package,
  Truck,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';
import { useOrder } from '@/contexts';
import type { OrderStatus } from '@/types';

const statusConfig: Record<OrderStatus, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: 'Pending', icon: Clock, color: '#F59E0B' },
  awaiting_payment: { label: 'Awaiting Payment', icon: Clock, color: '#F59E0B' },
  awaiting_confirmation: { label: 'Awaiting Confirmation', icon: Clock, color: '#3B82F6' },
  confirmed: { label: 'Confirmed', icon: CheckCircle, color: '#10B981' },
  processing: { label: 'Processing', icon: Package, color: '#8B5CF6' },
  shipped: { label: 'Shipped', icon: Truck, color: '#3B82F6' },
  delivered: { label: 'Delivered', icon: CheckCircle, color: '#10B981' },
  completed: { label: 'Completed', icon: CheckCircle, color: '#10B981' },
  cancelled: { label: 'Cancelled', icon: XCircle, color: '#EF4444' },
  refunded: { label: 'Refunded', icon: XCircle, color: '#6B7280' }
};

export function AdminOrdersPage() {
  const { orders } = useOrder();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.user.displayName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="admin-orders-page">
      {/* Header */}
      <div className="admin-header">
        <h1>Orders Management</h1>
        <p>View and manage all customer orders</p>
      </div>

      {/* Stats */}
      <div className="orders-stats">
        {Object.entries(statusConfig).slice(0, 5).map(([status, config]) => {
          const count = orders.filter(o => o.status === status).length;
          const Icon = config.icon;
          
          return (
            <motion.div
              key={status}
              className="stat-card"
              whileHover={{ y: -2 }}
            >
              <div 
                className="stat-icon"
                style={{ backgroundColor: `${config.color}20`, color: config.color }}
              >
                <Icon size={20} />
              </div>
              <div className="stat-info">
                <span className="stat-value">{count}</span>
                <span className="stat-label">{config.label}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search by order number or customer..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="filter-group">
          <Filter size={16} />
          <select 
            value={statusFilter} 
            onChange={(e) => setStatusFilter(e.target.value as any)}
          >
            <option value="all">All Status</option>
            {Object.entries(statusConfig).map(([status, config]) => (
              <option key={status} value={status}>{config.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="orders-table-container">
        <table className="orders-table">
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Total</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan={7} className="empty-cell">
                  <div className="empty-state">
                    <Package size={48} />
                    <p>No orders found</p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredOrders.map((order) => {
                const status = statusConfig[order.status];
                const StatusIcon = status?.icon || Package;
                
                return (
                  <motion.tr
                    key={order.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <td>
                      <span className="order-number">{order.orderNumber}</span>
                    </td>
                    <td>
                      <div className="customer-info">
                        <img 
                          src={order.user.photoURL || '/default-avatar.png'} 
                          alt={order.user.displayName}
                          className="customer-avatar"
                        />
                        <span>{order.user.displayName}</span>
                      </div>
                    </td>
                    <td>
                      <span className="items-count">{order.items.length} items</span>
                    </td>
                    <td>
                      <span className="amount">{formatPrice(order.total)}</span>
                    </td>
                    <td>
                      <span className="date">{formatDate(order.createdAt)}</span>
                    </td>
                    <td>
                      <span 
                        className="status-badge"
                        style={{ 
                          backgroundColor: `${status?.color}20`,
                          color: status?.color 
                        }}
                      >
                        <StatusIcon size={12} />
                        {status?.label}
                      </span>
                    </td>
                    <td>
                      <motion.button
                        className="btn-view"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Eye size={16} />
                      </motion.button>
                    </td>
                  </motion.tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
