// ============================================
// BLUEHAT STORE - ADMIN DASHBOARD PAGE
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { 
  ShoppingBag, 
  Users, 
  DollarSign, 
  Package,
  TrendingUp,
  Clock,
  AlertCircle,
  ArrowRight
} from 'lucide-react';
import { mockAdminStats, mockSalesChartData } from '@/data/mockData';
import { useOrder } from '@/contexts';

const statCards = [
  { 
    key: 'totalOrders', 
    label: 'Total Orders', 
    icon: ShoppingBag, 
    color: '#2563EB',
    format: (v: number) => v.toLocaleString()
  },
  { 
    key: 'totalRevenue', 
    label: 'Total Revenue', 
    icon: DollarSign, 
    color: '#10B981',
    format: (v: number) => `Rp ${(v / 1000000).toFixed(1)}M`
  },
  { 
    key: 'totalCustomers', 
    label: 'Customers', 
    icon: Users, 
    color: '#8B5CF6',
    format: (v: number) => v.toLocaleString()
  },
  { 
    key: 'totalProducts', 
    label: 'Products', 
    icon: Package, 
    color: '#F59E0B',
    format: (v: number) => v.toLocaleString()
  }
];

export function AdminDashboardPage() {
  const { pendingPayments } = useOrder();

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="admin-header">
        <h1>Dashboard</h1>
        <p>Welcome back, Admin</p>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        {statCards.map((card, index) => {
          const value = mockAdminStats[card.key as keyof typeof mockAdminStats];
          return (
            <motion.div
              key={card.key}
              className="stat-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div 
                className="stat-icon"
                style={{ backgroundColor: `${card.color}20`, color: card.color }}
              >
                <card.icon size={24} />
              </div>
              <div className="stat-info">
                <span className="stat-label">{card.label}</span>
                <span className="stat-value">{card.format(value as number)}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Alerts */}
      <div className="alerts-section">
        {mockAdminStats.pendingPayments > 0 && (
          <motion.div
            className="alert-card warning"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <AlertCircle size={20} />
            <div className="alert-content">
              <h4>Pending Payments</h4>
              <p>{mockAdminStats.pendingPayments} payments awaiting confirmation</p>
            </div>
            <motion.button
              className="btn-action"
              whileHover={{ x: 5 }}
            >
              Review <ArrowRight size={16} />
            </motion.button>
          </motion.div>
        )}

        {mockAdminStats.lowStockProducts > 0 && (
          <motion.div
            className="alert-card danger"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Package size={20} />
            <div className="alert-content">
              <h4>Low Stock Alert</h4>
              <p>{mockAdminStats.lowStockProducts} products running low</p>
            </div>
            <motion.button
              className="btn-action"
              whileHover={{ x: 5 }}
            >
              View <ArrowRight size={16} />
            </motion.button>
          </motion.div>
        )}
      </div>

      {/* Charts Section */}
      <div className="charts-section">
        <motion.div
          className="chart-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="chart-header">
            <h3>Sales Overview</h3>
            <div className="chart-legend">
              <span className="legend-item">
                <span className="dot" style={{ backgroundColor: '#2563EB' }} />
                Revenue
              </span>
            </div>
          </div>
          <div className="chart-content">
            {/* Simple bar chart visualization */}
            <div className="bar-chart">
              {mockSalesChartData.labels.map((label, index) => {
                const revenue = mockSalesChartData.revenue[index];
                const maxRevenue = Math.max(...mockSalesChartData.revenue);
                const height = (revenue / maxRevenue) * 100;
                
                return (
                  <div key={label} className="bar-item">
                    <motion.div
                      className="bar"
                      style={{ height: `${height}%` }}
                      initial={{ height: 0 }}
                      animate={{ height: `${height}%` }}
                      transition={{ delay: index * 0.05, duration: 0.5 }}
                    />
                    <span className="bar-label">{label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>

        <motion.div
          className="chart-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="chart-header">
            <h3>Recent Activity</h3>
          </div>
          <div className="activity-list">
            {[
              { action: 'New order received', time: '2 minutes ago', icon: ShoppingBag },
              { action: 'Payment confirmed', time: '15 minutes ago', icon: DollarSign },
              { action: 'New customer registered', time: '1 hour ago', icon: Users },
              { action: 'Product stock updated', time: '2 hours ago', icon: Package },
              { action: 'Review submitted', time: '3 hours ago', icon: TrendingUp }
            ].map((activity, index) => (
              <div key={index} className="activity-item">
                <div className="activity-icon">
                  <activity.icon size={16} />
                </div>
                <div className="activity-content">
                  <p>{activity.action}</p>
                  <span><Clock size={12} /> {activity.time}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        className="quick-actions"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h3>Quick Actions</h3>
        <div className="actions-grid">
          {[
            { label: 'Add Product', icon: Package, color: '#2563EB' },
            { label: 'View Orders', icon: ShoppingBag, color: '#10B981' },
            { label: 'Manage Users', icon: Users, color: '#8B5CF6' },
            { label: 'View Reports', icon: TrendingUp, color: '#F59E0B' }
          ].map((action) => (
            <motion.button
              key={action.label}
              className="action-card"
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <div 
                className="action-icon"
                style={{ backgroundColor: `${action.color}20`, color: action.color }}
              >
                <action.icon size={24} />
              </div>
              <span>{action.label}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
