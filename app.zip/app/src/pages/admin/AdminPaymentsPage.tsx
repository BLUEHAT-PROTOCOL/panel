// ============================================
// BLUEHAT STORE - ADMIN PAYMENTS PAGE
// ============================================

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Check, 
  X, 
  Eye,
  Clock,
  Filter,
  ChevronLeft,
  ChevronRight,
  Download
} from 'lucide-react';
import { useOrder, useNotification } from '@/contexts';
import { paymentMethods } from '@/data/mockData';

export function AdminPaymentsPage() {
  const { pendingPayments, confirmPayment, rejectPayment } = useOrder();
  const { addNotification } = useNotification();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'awaiting_confirmation'>('awaiting_confirmation');
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const filteredPayments = pendingPayments.filter(payment => {
    const matchesSearch = 
      payment.order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.order.user.displayName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = filter === 'all' || payment.status === filter;
    
    return matchesSearch && matchesFilter;
  });

  const handleConfirm = async (paymentId: string) => {
    await confirmPayment(paymentId);
    
    const payment = pendingPayments.find(p => p.id === paymentId);
    if (payment) {
      addNotification({
        userId: payment.order.userId,
        type: 'payment_confirmed',
        title: 'Payment Confirmed',
        message: `Your payment for order ${payment.order.orderNumber} has been confirmed.`,
        data: { orderId: payment.orderId }
      });
    }
  };

  const handleReject = async () => {
    if (!selectedPayment) return;
    
    await rejectPayment(selectedPayment, rejectionReason);
    setShowRejectModal(false);
    setRejectionReason('');
    setSelectedPayment(null);
  };

  const openRejectModal = (paymentId: string) => {
    setSelectedPayment(paymentId);
    setShowRejectModal(true);
  };

  return (
    <div className="admin-payments-page">
      {/* Header */}
      <div className="admin-header">
        <h1>Payment Confirmations</h1>
        <p>Verify and confirm customer payments</p>
      </div>

      {/* Stats */}
      <div className="payment-stats">
        <div className="stat-item">
          <span className="stat-value">{pendingPayments.filter(p => p.status === 'awaiting_confirmation').length}</span>
          <span className="stat-label">Awaiting Confirmation</span>
        </div>
        <div className="stat-item">
          <span className="stat-value">
            {formatPrice(pendingPayments
              .filter(p => p.status === 'awaiting_confirmation')
              .reduce((sum, p) => sum + p.amount, 0))}
          </span>
          <span className="stat-label">Total Pending</span>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search by order number or customer..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="filter-group">
          <Filter size={16} />
          <select value={filter} onChange={(e) => setFilter(e.target.value as any)}>
            <option value="awaiting_confirmation">Awaiting Confirmation</option>
            <option value="all">All Payments</option>
          </select>
        </div>
      </div>

      {/* Payments Table */}
      <div className="payments-table-container">
        <table className="payments-table">
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Method</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPayments.length === 0 ? (
              <tr>
                <td colSpan={7} className="empty-cell">
                  <div className="empty-state">
                    <Clock size={48} />
                    <p>No pending payments</p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredPayments.map((payment) => (
                <motion.tr
                  key={payment.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <td>
                    <span className="order-number">{payment.order.orderNumber}</span>
                  </td>
                  <td>
                    <div className="customer-info">
                      <img 
                        src={payment.order.user.photoURL || '/default-avatar.png'} 
                        alt={payment.order.user.displayName}
                        className="customer-avatar"
                      />
                      <span>{payment.order.user.displayName}</span>
                    </div>
                  </td>
                  <td>
                    <span className="payment-method">
                      {paymentMethods.find(m => m.id === payment.method)?.name || payment.method}
                    </span>
                  </td>
                  <td>
                    <span className="amount">{formatPrice(payment.amount)}</span>
                  </td>
                  <td>
                    <span className="date">{formatDate(payment.createdAt)}</span>
                  </td>
                  <td>
                    <span className={`status-badge ${payment.status}`}>
                      {payment.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      {payment.status === 'awaiting_confirmation' && (
                        <>
                          <motion.button
                            className="btn-confirm"
                            onClick={() => handleConfirm(payment.id)}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            title="Confirm Payment"
                          >
                            <Check size={16} />
                          </motion.button>
                          <motion.button
                            className="btn-reject"
                            onClick={() => openRejectModal(payment.id)}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            title="Reject Payment"
                          >
                            <X size={16} />
                          </motion.button>
                        </>
                      )}
                      {payment.proofImage && (
                        <motion.button
                          className="btn-view"
                          onClick={() => window.open(payment.proofImage, '_blank')}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          title="View Proof"
                        >
                          <Eye size={16} />
                        </motion.button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Reject Modal */}
      <AnimatePresence>
        {showRejectModal && (
          <div className="modal-overlay">
            <motion.div
              className="modal-container small"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
            >
              <h3>Reject Payment</h3>
              <p>Please provide a reason for rejecting this payment.</p>
              <textarea
                placeholder="Enter rejection reason..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
              />
              <div className="modal-actions">
                <button 
                  className="btn-secondary"
                  onClick={() => setShowRejectModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn-danger"
                  onClick={handleReject}
                  disabled={!rejectionReason.trim()}
                >
                  Reject Payment
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
