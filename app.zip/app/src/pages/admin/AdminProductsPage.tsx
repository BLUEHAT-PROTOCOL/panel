// ============================================
// BLUEHAT STORE - ADMIN PRODUCTS PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Plus,
  Edit2,
  Trash2,
  Filter,
  Package,
  AlertCircle
} from 'lucide-react';
import { mockProducts, mockCategories } from '@/data/mockData';

export function AdminProductsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [stockFilter, setStockFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'out_of_stock'>('all');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || product.category === mockCategories.find(c => c.id === categoryFilter)?.name;
    
    const matchesStock = stockFilter === 'all' || product.stockStatus === stockFilter;
    
    return matchesSearch && matchesCategory && matchesStock;
  });

  const lowStockCount = mockProducts.filter(p => p.stockStatus === 'low_stock').length;
  const outOfStockCount = mockProducts.filter(p => p.stockStatus === 'out_of_stock').length;

  return (
    <div className="admin-products-page">
      {/* Header */}
      <div className="admin-header">
        <h1>Products Management</h1>
        <p>Manage your product catalog</p>
      </div>

      {/* Alerts */}
      {(lowStockCount > 0 || outOfStockCount > 0) && (
        <div className="alerts-section">
          {lowStockCount > 0 && (
            <div className="alert-card warning">
              <AlertCircle size={18} />
              <span>{lowStockCount} products are running low on stock</span>
            </div>
          )}
          {outOfStockCount > 0 && (
            <div className="alert-card danger">
              <AlertCircle size={18} />
              <span>{outOfStockCount} products are out of stock</span>
            </div>
          )}
        </div>
      )}

      {/* Stats */}
      <div className="products-stats">
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#2563EB20', color: '#2563EB' }}>
            <Package size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">{mockProducts.length}</span>
            <span className="stat-label">Total Products</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#10B98120', color: '#10B981' }}>
            <Package size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">{mockProducts.filter(p => p.isActive).length}</span>
            <span className="stat-label">Active</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#F59E0B20', color: '#F59E0B' }}>
            <Package size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">{lowStockCount}</span>
            <span className="stat-label">Low Stock</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#EF444420', color: '#EF4444' }}>
            <Package size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-value">{outOfStockCount}</span>
            <span className="stat-label">Out of Stock</span>
          </div>
        </div>
      </div>

      {/* Actions Bar */}
      <div className="actions-bar">
        <div className="filters">
          <div className="search-box">
            <Search size={18} />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <select 
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="all">All Categories</option>
            {mockCategories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
          <select
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value as any)}
          >
            <option value="all">All Stock</option>
            <option value="in_stock">In Stock</option>
            <option value="low_stock">Low Stock</option>
            <option value="out_of_stock">Out of Stock</option>
          </select>
        </div>
        <motion.button
          className="btn-primary"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Plus size={18} />
          Add Product
        </motion.button>
      </div>

      {/* Products Table */}
      <div className="products-table-container">
        <table className="products-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>SKU</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.length === 0 ? (
              <tr>
                <td colSpan={7} className="empty-cell">
                  <div className="empty-state">
                    <Package size={48} />
                    <p>No products found</p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredProducts.map((product) => (
                <motion.tr
                  key={product.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <td>
                    <div className="product-info">
                      <img 
                        src={product.thumbnail} 
                        alt={product.name}
                        className="product-thumb"
                      />
                      <div>
                        <span className="product-name">{product.name}</span>
                        <span className="product-type">{product.type}</span>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className="sku">{product.sku}</span>
                  </td>
                  <td>
                    <span className="category">{product.category}</span>
                  </td>
                  <td>
                    <div className="price">
                      {product.salePrice && (
                        <span className="sale-price">{formatPrice(product.salePrice)}</span>
                      )}
                      <span className={product.salePrice ? 'original' : ''}>
                        {formatPrice(product.price)}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="stock">
                      <span className={`stock-badge ${product.stockStatus}`}>
                        {product.stock}
                      </span>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${product.isActive ? 'active' : 'inactive'}`}>
                      {product.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <motion.button
                        className="btn-edit"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Edit2 size={16} />
                      </motion.button>
                      <motion.button
                        className="btn-delete"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Trash2 size={16} />
                      </motion.button>
                    </div>
                  </td>
                </motion.tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
