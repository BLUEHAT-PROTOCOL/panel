// ============================================
// BLUEHAT STORE - ORDER SUCCESS PAGE
// ============================================

import React from 'react';
import { motion } from 'framer-motion';
import { Check, Package, Clock, ArrowRight, Home, FileText } from 'lucide-react';
import { useOrder } from '@/contexts';

interface OrderSuccessPageProps {
  orderId: string;
  onViewOrder: (orderId: string) => void;
  onContinueShopping: () => void;
}

export function OrderSuccessPage({ orderId, onViewOrder, onContinueShopping }: OrderSuccessPageProps) {
  const { getOrderById } = useOrder();
  const order = getOrderById(orderId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <div className="order-success-page">
      <motion.div
        className="success-container"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Success Icon */}
        <motion.div
          className="success-icon"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
        >
          <div className="icon-circle">
            <Check size={48} strokeWidth={3} />
          </div>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          Payment Proof Submitted!
        </motion.h1>

        {/* Message */}
        <motion.p
          className="success-message"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          Thank you for your payment. We will verify your payment within 15-30 minutes.
          You will receive a notification once your order is confirmed.
        </motion.p>

        {/* Order Details */}
        {order && (
          <motion.div
            className="order-details-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="detail-row">
              <span>Order Number</span>
              <strong>{order.orderNumber}</strong>
            </div>
            <div className="detail-row">
              <span>Total Amount</span>
              <strong>{formatPrice(order.total)}</strong>
            </div>
            <div className="detail-row">
              <span>Payment Method</span>
              <strong className="capitalize">{order.paymentMethod}</strong>
            </div>
            <div className="detail-row">
              <span>Status</span>
              <span className="status-badge awaiting">Awaiting Confirmation</span>
            </div>
          </motion.div>
        )}

        {/* What Happens Next */}
        <motion.div
          className="next-steps"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h3>What Happens Next?</h3>
          <div className="steps-list">
            <div className="step">
              <div className="step-icon">
                <Clock size={20} />
              </div>
              <div className="step-content">
                <h4>Verification</h4>
                <p>We will verify your payment within 15-30 minutes</p>
              </div>
            </div>
            <div className="step">
              <div className="step-icon">
                <Check size={20} />
              </div>
              <div className="step-content">
                <h4>Confirmation</h4>
                <p>You will receive email and notification confirmation</p>
              </div>
            </div>
            <div className="step">
              <div className="step-icon">
                <Package size={20} />
              </div>
              <div className="step-content">
                <h4>Delivery</h4>
                <p>Your digital products will be delivered instantly</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          className="success-actions"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <motion.button
            className="btn-primary btn-large"
            onClick={() => onViewOrder(orderId)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FileText size={18} />
            View Order Details
          </motion.button>
          <motion.button
            className="btn-secondary btn-large"
            onClick={onContinueShopping}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Home size={18} />
            Continue Shopping
          </motion.button>
        </motion.div>
      </motion.div>
    </div>
  );
}
