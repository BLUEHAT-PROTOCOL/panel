// ============================================
// BLUEHAT STORE - ORDER HISTORY PAGE
// ============================================

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Package, 
  ChevronRight,
  Clock,
  CheckCircle,
  XCircle,
  Truck
} from 'lucide-react';
import { useOrder, useAuth } from '@/contexts';
import type { OrderStatus } from '@/types';

interface OrderHistoryPageProps {
  onBack: () => void;
  onViewOrder: (orderId: string) => void;
}

const statusConfig: Record<OrderStatus, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: 'Pending', icon: Clock, color: '#F59E0B' },
  awaiting_payment: { label: 'Awaiting Payment', icon: Clock, color: '#F59E0B' },
  awaiting_confirmation: { label: 'Awaiting Confirmation', icon: Clock, color: '#3B82F6' },
  confirmed: { label: 'Confirmed', icon: CheckCircle, color: '#10B981' },
  processing: { label: 'Processing', icon: Package, color: '#8B5CF6' },
  shipped: { label: 'Shipped', icon: Truck, color: '#3B82F6' },
  delivered: { label: 'Delivered', icon: CheckCircle, color: '#10B981' },
  completed: { label: 'Completed', icon: CheckCircle, color: '#10B981' },
  cancelled: { label: 'Cancelled', icon: XCircle, color: '#EF4444' },
  refunded: { label: 'Refunded', icon: XCircle, color: '#6B7280' }
};

export function OrderHistoryPage({ onBack, onViewOrder }: OrderHistoryPageProps) {
  const { orders } = useOrder();
  const { user } = useAuth();
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all');

  const userOrders = orders.filter(o => o.userId === user?.id);
  
  const filteredOrders = filter === 'all' 
    ? userOrders 
    : userOrders.filter(o => o.status === filter);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="order-history-page">
      {/* Header */}
      <div className="page-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>
        <h1>My Orders</h1>
      </div>

      {/* Filter Tabs */}
      <div className="order-filters">
        {(['all', 'pending', 'awaiting_confirmation', 'confirmed', 'completed', 'cancelled'] as const).map((status) => (
          <motion.button
            key={status}
            className={`filter-tab ${filter === status ? 'active' : ''}`}
            onClick={() => setFilter(status)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {status === 'all' ? 'All Orders' : statusConfig[status]?.label}
          </motion.button>
        ))}
      </div>

      {/* Orders List */}
      <div className="orders-list">
        {filteredOrders.length === 0 ? (
          <motion.div
            className="empty-state"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <Package size={64} />
            <h3>No orders found</h3>
            <p>You haven't placed any orders yet.</p>
          </motion.div>
        ) : (
          filteredOrders.map((order, index) => {
            const status = statusConfig[order.status];
            const StatusIcon = status?.icon || Package;

            return (
              <motion.div
                key={order.id}
                className="order-card"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => onViewOrder(order.id)}
                whileHover={{ scale: 1.01 }}
              >
                <div className="order-header">
                  <div className="order-info">
                    <span className="order-number">{order.orderNumber}</span>
                    <span className="order-date">{formatDate(order.createdAt)}</span>
                  </div>
                  <div 
                    className="order-status"
                    style={{ 
                      backgroundColor: `${status?.color}20`,
                      color: status?.color 
                    }}
                  >
                    <StatusIcon size={14} />
                    {status?.label}
                  </div>
                </div>

                <div className="order-items">
                  {order.items.slice(0, 2).map((item) => (
                    <div key={item.id} className="order-item">
                      <img 
                        src={item.product.thumbnail} 
                        alt={item.product.name}
                        loading="lazy"
                      />
                      <div className="item-info">
                        <p className="item-name">{item.product.name}</p>
                        <p className="item-qty">x{item.quantity}</p>
                      </div>
                    </div>
                  ))}
                  {order.items.length > 2 && (
                    <div className="more-items">
                      +{order.items.length - 2} more items
                    </div>
                  )}
                </div>

                <div className="order-footer">
                  <div className="order-total">
                    <span>Total</span>
                    <strong>{formatPrice(order.total)}</strong>
                  </div>
                  <motion.button
                    className="view-details-btn"
                    whileHover={{ x: 5 }}
                  >
                    View Details
                    <ChevronRight size={16} />
                  </motion.button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
