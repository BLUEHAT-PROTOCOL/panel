// ============================================
// BLUEHAT STORE - PAYMENT PAGE
// ============================================

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Clock, 
  Copy, 
  Check, 
  Upload,
  AlertCircle,
  QrCode
} from 'lucide-react';
import { useOrder } from '@/contexts';
import { paymentMethods } from '@/data/mockData';

interface PaymentPageProps {
  orderId: string;
  onBack: () => void;
  onUploadProof: (orderId: string) => void;
}

export function PaymentPage({ orderId, onBack, onUploadProof }: PaymentPageProps) {
  const { getOrderById } = useOrder();
  const order = getOrderById(orderId);
  
  const [timeLeft, setTimeLeft] = useState('');
  const [copied, setCopied] = useState(false);

  const paymentMethod = paymentMethods.find(p => p.id === order?.paymentMethod);

  useEffect(() => {
    if (!order?.expiredAt) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const expiry = new Date(order.expiredAt!).getTime();
      const diff = expiry - now;

      if (diff <= 0) {
        setTimeLeft('Expired');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [order?.expiredAt]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!order) {
    return (
      <div className="payment-page">
        <div className="not-found">
          <AlertCircle size={64} />
          <h2>Order Not Found</h2>
          <button className="btn-primary" onClick={onBack}>
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="payment-page">
      {/* Header */}
      <div className="payment-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back to Orders
        </motion.button>
        <h1>Complete Payment</h1>
      </div>

      <div className="payment-layout">
        {/* Payment Details */}
        <motion.div
          className="payment-details"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Timer */}
          <div className="payment-timer">
            <Clock size={20} />
            <div>
              <span className="timer-label">Complete payment before:</span>
              <span className={`timer-value ${timeLeft === 'Expired' ? 'expired' : ''}`}>
                {timeLeft}
              </span>
            </div>
          </div>

          {/* Order Info */}
          <div className="order-info-card">
            <h3>Order #{order.orderNumber}</h3>
            <div className="info-row">
              <span>Total Amount</span>
              <span className="amount">{formatPrice(order.total)}</span>
            </div>
          </div>

          {/* Payment Method */}
          <div className="payment-method-card">
            <h3>Payment Method</h3>
            <div className="method-name">
              {paymentMethod?.name || order.paymentMethod}
            </div>

            {/* QRIS */}
            {paymentMethod?.category === 'qris' && (
              <div className="qris-section">
                <div className="qris-code">
                  <QrCode size={200} />
                </div>
                <p>Scan QR code with your e-wallet or banking app</p>
              </div>
            )}

            {/* Bank/E-wallet Details */}
            {(paymentMethod?.category === 'bank' || paymentMethod?.category === 'ewallet') && (
              <div className="account-details">
                <div className="detail-row">
                  <span>Account Number</span>
                  <div className="copy-field">
                    <strong>{paymentMethod?.accountNumber}</strong>
                    <motion.button
                      onClick={() => copyToClipboard(paymentMethod?.accountNumber || '')}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      {copied ? <Check size={16} /> : <Copy size={16} />}
                    </motion.button>
                  </div>
                </div>
                <div className="detail-row">
                  <span>Account Name</span>
                  <strong>{paymentMethod?.accountName}</strong>
                </div>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="instructions-card">
            <h3>Payment Instructions</h3>
            <ol>
              {paymentMethod?.instructions.map((instruction, index) => (
                <li key={index}>{instruction}</li>
              ))}
            </ol>
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          className="payment-actions"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="action-card">
            <h3>Already Paid?</h3>
            <p>Upload your payment proof to confirm your order</p>
            <motion.button
              className="btn-primary btn-large btn-full"
              onClick={() => onUploadProof(orderId)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Upload size={18} />
              Upload Payment Proof
            </motion.button>
          </div>

          <div className="help-card">
            <h4>Need Help?</h4>
            <p>If you have any issues with payment, contact our support team</p>
            <a href="mailto:support@bluehat.store">support@bluehat.store</a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
