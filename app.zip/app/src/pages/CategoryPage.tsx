// ============================================
// BLUEHAT STORE - CATEGORY PAGE
// ============================================

import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Star,
  ShoppingCart,
  SlidersHorizontal
} from 'lucide-react';
import { mockProducts, mockCategories } from '@/data/mockData';
import { useCart } from '@/contexts';

interface CategoryPageProps {
  categoryId: string;
  onProductClick: (productId: string) => void;
  onBack: () => void;
}

export function CategoryPage({ categoryId, onProductClick, onBack }: CategoryPageProps) {
  const { addToCart } = useCart();
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'newest' | 'popular'>('popular');
  const [priceFilter, setPriceFilter] = useState<'all' | 'under50k' | '50k-100k' | '100k-500k' | 'above500k'>('all');

  const category = mockCategories.find(c => c.id === categoryId);

  const filteredProducts = useMemo(() => {
    let products = mockProducts.filter(p => p.category === category?.name);

    // Price filter
    if (priceFilter !== 'all') {
      products = products.filter(p => {
        const price = p.salePrice || p.price;
        switch (priceFilter) {
          case 'under50k':
            return price < 50000;
          case '50k-100k':
            return price >= 50000 && price < 100000;
          case '100k-500k':
            return price >= 100000 && price < 500000;
          case 'above500k':
            return price >= 500000;
          default:
            return true;
        }
      });
    }

    // Sort
    products.sort((a, b) => {
      switch (sortBy) {
        case 'price_asc':
          return (a.salePrice || a.price) - (b.salePrice || b.price);
        case 'price_desc':
          return (b.salePrice || b.price) - (a.salePrice || a.price);
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'popular':
        default:
          return b.soldCount - a.soldCount;
      }
    });

    return products;
  }, [category?.name, priceFilter, sortBy]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleAddToCart = (e: React.MouseEvent, product: typeof mockProducts[0]) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  if (!category) {
    return (
      <div className="category-page">
        <div className="not-found">
          <h2>Category Not Found</h2>
          <button className="btn-primary" onClick={onBack}>
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="category-page">
      {/* Header */}
      <div 
        className="category-header"
        style={{
          backgroundImage: `linear-gradient(rgba(5, 11, 30, 0.8), rgba(5, 11, 30, 0.9)), url(${category.image})`
        }}
      >
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>
        
        <motion.div
          className="category-info"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1>{category.name}</h1>
          <p>{category.description}</p>
          <span className="product-count">{filteredProducts.length} products</span>
        </motion.div>
      </div>

      {/* Filters */}
      <div className="category-filters">
        <div className="filter-group">
          <SlidersHorizontal size={16} />
          <select 
            value={priceFilter}
            onChange={(e) => setPriceFilter(e.target.value as any)}
          >
            <option value="all">All Prices</option>
            <option value="under50k">Under Rp 50.000</option>
            <option value="50k-100k">Rp 50.000 - Rp 100.000</option>
            <option value="100k-500k">Rp 100.000 - Rp 500.000</option>
            <option value="above500k">Above Rp 500.000</option>
          </select>
        </div>

        <div className="filter-group">
          <span>Sort by:</span>
          <select 
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
          >
            <option value="popular">Most Popular</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="newest">Newest</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      <div className="category-products">
        {filteredProducts.length === 0 ? (
          <div className="no-products">
            <p>No products found in this category</p>
          </div>
        ) : (
          <div className="products-grid">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                className="product-card"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onProductClick(product.id)}
                whileHover={{ y: -5 }}
              >
                <div className="card-image">
                  <img 
                    src={product.thumbnail} 
                    alt={product.name}
                    loading="lazy"
                  />
                  {product.salePrice && (
                    <span className="sale-badge">
                      {Math.round((1 - product.salePrice / product.price) * 100)}% OFF
                    </span>
                  )}
                  <motion.button
                    className="quick-add"
                    onClick={(e) => handleAddToCart(e, product)}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ShoppingCart size={16} />
                  </motion.button>
                </div>
                
                <div className="card-content">
                  <h3 className="product-name">{product.name}</h3>
                  
                  <div className="product-rating">
                    <div className="stars">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={12}
                          className={i < Math.floor(product.rating) ? 'filled' : ''}
                        />
                      ))}
                    </div>
                    <span>({product.reviewCount})</span>
                  </div>

                  <div className="product-price">
                    {product.salePrice ? (
                      <>
                        <span className="sale-price">
                          {formatPrice(product.salePrice)}
                        </span>
                        <span className="original-price">
                          {formatPrice(product.price)}
                        </span>
                      </>
                    ) : (
                      <span className="price">{formatPrice(product.price)}</span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
