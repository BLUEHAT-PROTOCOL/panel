// ============================================
// BLUEHAT STORE - PAYMENT CONFIRMATION PAGE
// ============================================

import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Upload, 
  X, 
  Check,
  AlertCircle,
  Camera
} from 'lucide-react';
import { useOrder } from '@/contexts';

interface PaymentConfirmPageProps {
  orderId: string;
  onBack: () => void;
  onSuccess: (orderId: string) => void;
}

export function PaymentConfirmPage({ orderId, onBack, onSuccess }: PaymentConfirmPageProps) {
  const { getOrderById, uploadPaymentProof } = useOrder();
  const order = getOrderById(orderId);
  
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [senderName, setSenderName] = useState('');
  const [senderAccount, setSenderAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('File size must be less than 5MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!previewImage) {
      setError('Please upload payment proof');
      return;
    }
    
    if (!senderName.trim()) {
      setError('Please enter sender name');
      return;
    }
    
    if (!transferAmount.trim()) {
      setError('Please enter transfer amount');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      await uploadPaymentProof(orderId, previewImage, {
        senderName: senderName.trim(),
        senderAccount: senderAccount.trim(),
        transferDate: new Date(),
        transferAmount: parseFloat(transferAmount),
        notes: notes.trim()
      });
      
      onSuccess(orderId);
    } catch (err) {
      setError('Failed to upload payment proof. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!order) {
    return (
      <div className="payment-confirm-page">
        <div className="not-found">
          <AlertCircle size={64} />
          <h2>Order Not Found</h2>
          <button className="btn-primary" onClick={onBack}>
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="payment-confirm-page">
      {/* Header */}
      <div className="page-header">
        <motion.button
          className="back-button"
          onClick={onBack}
          whileHover={{ x: -5 }}
        >
          <ArrowLeft size={20} />
          Back
        </motion.button>
        <h1>Upload Payment Proof</h1>
      </div>

      <div className="confirm-layout">
        {/* Form */}
        <motion.form
          className="confirm-form"
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Order Summary */}
          <div className="order-summary-card">
            <h3>Order #{order.orderNumber}</h3>
            <div className="summary-row">
              <span>Amount to Pay</span>
              <span className="amount">{formatPrice(order.total)}</span>
            </div>
          </div>

          {/* Image Upload */}
          <div className="upload-section">
            <label className="upload-label">Payment Proof *</label>
            <div 
              className={`upload-area ${previewImage ? 'has-image' : ''}`}
              onClick={() => fileInputRef.current?.click()}
            >
              {previewImage ? (
                <div className="preview-container">
                  <img src={previewImage} alt="Payment proof" />
                  <motion.button
                    type="button"
                    className="remove-image"
                    onClick={(e) => {
                      e.stopPropagation();
                      setPreviewImage(null);
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <X size={18} />
                  </motion.button>
                </div>
              ) : (
                <div className="upload-placeholder">
                  <Camera size={48} />
                  <p>Click to upload or drag and drop</p>
                  <span>PNG, JPG up to 5MB</span>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                hidden
              />
            </div>
          </div>

          {/* Form Fields */}
          <div className="form-fields">
            <div className="form-group">
              <label>Sender Name *</label>
              <input
                type="text"
                placeholder="Enter sender name"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label>Sender Account/Number (Optional)</label>
              <input
                type="text"
                placeholder="Enter account number"
                value={senderAccount}
                onChange={(e) => setSenderAccount(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label>Transfer Amount *</label>
              <input
                type="number"
                placeholder="Enter transfer amount"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label>Notes (Optional)</label>
              <textarea
                placeholder="Any additional information"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          {error && (
            <div className="error-message">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          <motion.button
            type="submit"
            className="btn-primary btn-large btn-full"
            disabled={isSubmitting}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Payment Proof'}
          </motion.button>
        </motion.form>

        {/* Instructions */}
        <motion.div
          className="instructions-sidebar"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3>Tips for Payment Proof</h3>
          <ul>
            <li>
              <Check size={16} />
              Make sure the image is clear and readable
            </li>
            <li>
              <Check size={16} />
              Include the transaction date and time
            </li>
            <li>
              <Check size={16} />
              Show the amount transferred
            </li>
            <li>
              <Check size={16} />
              Include sender and recipient details
            </li>
            <li>
              <Check size={16} />
              Screenshot from banking app is preferred
            </li>
          </ul>

          <div className="help-box">
            <h4>Need Help?</h4>
            <p>Contact our support if you have any issues</p>
            <a href="mailto:support@bluehat.store">support@bluehat.store</a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
